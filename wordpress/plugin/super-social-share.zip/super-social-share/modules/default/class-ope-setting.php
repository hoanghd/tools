<?php
class OPE_Default_Setting extends OPE_Abstract{
    public function index(){
         $this->render('index');
    }
}
?>