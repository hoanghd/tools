<?php
class OPE_Default_Customizer extends OPE_Abstract{
    public function index(){
         
    }
}
?>