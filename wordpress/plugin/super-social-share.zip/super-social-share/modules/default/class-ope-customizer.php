<?php
class OPE_Default_Customizer extends OPE_Abstract{
    public function index(){
         $this->render('index');
    }
    
    public function view(){
         $this->render('view');
    }
    
    public function load(){
        wp_send_json(array(
            'Network' => array(
                array('type' => 'facebook', 'name'=>'Facebook'),
                array('type' => 'twitter', 'name'=>'Twitter'),
                array('type' => 'pinterest', 'name' =>'Pinterest'),
                array('type' => 'google-plus', 'name' =>'Google plus')
            ),
            'NetworkSetting' => array(
                'button' => 'popup',
                'icon' => 'dot',
                'max_display' => 2,
                'cnt' => 4
            ),
            'Template' => array(
                'type' => 'icon-name-count',
                'pos_count' => 'left',
                'min_count' => 50,
                'pos_total' => 'left',
                'min_total' => 50,
                'min_total_count' => 100,
                'mode' => 'cache'
            ),
            'Social' => OPE_Manager::get_data('social')
        ));
    }
    
    public function save(){
        wp_send_json(array());
    }
}
?>