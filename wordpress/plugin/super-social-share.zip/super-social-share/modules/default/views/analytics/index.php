<div id="container" style="padding:50px;"></div>
<script type="text/template" name="movie">
	Title: <%=title%>;
	<div class="rating" style="<%=style%>">Rating: <%=rating%></div>
</script> 