<div class="ope-item-content ope-customizer-template">
    <div class="form-group">
        <label>Template network:</label>
        <div fn="select2" data-model="model" data-name="type"></div>
    </div>
    <div class="form-group has-counter" fn-if="<%=(/count/.test(model.get('type')) ? 1 : 0)%>">
        <label>Counter Position:</label>
        <div fn="select2" data-model="model" data-name="pos_count"></div>
    </div>
    <div class="form-group has-counter" fn-if="<%=(/count/.test(model.get('type')) ? 1 : 0)%>">
        <div class="row">
            <div class="col-sm-8">
                <label class="m-b-20">Set Counter min:</label>
                <div fn="slider" data-model="model" data-name="min_count" data-html-options='{"stop": "slideCount"}'></div>
            </div>
            <div class="col-sm-4 p-a-0">
                <label class="m-b-20"></label>
                <div fn="numberField" data-model="model" data-name="min_count" data-html-options='{"class": "form-control ope-input-xsmall"}'></div>
            </div>
        </div>
    </div>
    <div class="form-group has-total-counter"  fn-if="<%=(/total/.test(model.get('type')) ? 1 : 0)%>">
        <label>Total Counter Position:</label>
        <div fn="select2" data-model="model" data-name="pos_total"></div>
    </div>
    <div class="form-group has-total-counter" fn-if="<%=(/total/.test(model.get('type')) ? 1 : 0)%>">
        <div class="row">
            <div class="col-sm-8">
                <label class="m-b-20">Set Total Counter min:</label>
                <div fn="slider" data-model="model" data-name="min_count" data-html-options='{"stop": "slideTotal"}'></div>
            </div>
            <div class="col-sm-4 p-a-0">
                <label class="m-b-20"></label>
                <div fn="numberField" data-model="model" data-name="min_total" data-html-options='{"class": "form-control ope-input-xsmall"}'></div>
            </div>
        </div>
    </div>
    <div class="form-group" fn-if="<%=(/count/.test(model.get('type')) ? 1 : 0)%>">
        <label>Counter update mode:</label>
        <div fn="select2" data-model="model" data-name="mode"></div>
    </div>
</div>