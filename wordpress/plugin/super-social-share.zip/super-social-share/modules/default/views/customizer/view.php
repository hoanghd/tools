<div id="preview"></div>
<script type="text/template" name="Preview">
    <ul class="ope-link-list ope-template-icon ope-template-name ope-template-count">
        <% if( !_.isEmpty( data.Network ) ){%>
        <% _.each( data.Network, function( row, index ){ %>
            <% if( index < ( data.NetworkSetting.max_display || data.NetworkSetting.cnt ) ){ %>
                <%=$ope.social(row)%>
            <% } %>
        <% })%>
		<li class="ope-social-link ope-btn-more-networks <%=(data.NetworkSetting.icon == 'dot' ? 'ope-icon-dot' : '')%>">
			<a href="#"></a>
		</li>
        <% } %>
    </ul>
</script>