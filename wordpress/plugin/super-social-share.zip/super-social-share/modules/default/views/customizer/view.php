<div id="preview"></div>
<script type="text/template" name="Preview">
    <ul class="ope-link-list <%=$ope.type(data.Template)%>">
        <% if( !_.isEmpty( data.Network ) ){%>
        <% _.each( data.Network, function( row, index ){ %>
            <% if( index < ( data.NetworkSetting.max_display || data.NetworkSetting.cnt ) ){ %>
                <%=$ope.total( row, data.Template, 'left' )%>
                <%=$ope.social(row)%>
                <%=$ope.total( row, data.Template, 'right' )%>
            <% } %>
        <% })%>
        <li class="ope-social-link ope-btn-more-networks <%=(data.NetworkSetting.icon == 'dot' ? 'ope-icon-dot' : '')%>">
            <a href="#"></a>
        </li>
        <% } %>
    </ul>
</script>