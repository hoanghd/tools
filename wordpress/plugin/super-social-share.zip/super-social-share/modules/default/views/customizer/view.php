<div id="preview"></div>
<script type="text/template" name="Preview">
    <ul class="ope-link-list ope-template-icon ope-template-name ope-template-count">
        <% if( !_.isEmpty( data.Network ) ){%>
        <% _.each( data.Network, function( row ){ %>
            <%=$ope.social(row)%>
        <% })%>
        <% } %>
    </ul>
</script>