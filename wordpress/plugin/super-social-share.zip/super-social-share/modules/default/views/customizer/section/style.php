<div class="ope-item-content ope-customizer-style">
    <div class="form-group">
        <div class="row">
            <div class="col-sm-6">
                <label>Style:</label>
                <select class="form-control ope-input-small ope-select2" data-placeholder="Select a style">
                    <option>Flat</option>
                    <option>3D</option>
                    <option>Outlined</option>
                </select>
            </div>
            <div class="col-sm-6">
                <label>Shape:</label>
                <select class="form-control ope-input-small ope-select2" data-placeholder="Select a shape">
                    <option>Rounded</option>
                    <option>Squared</option>
                    <option>Circled</option>
                </select>
            </div>
        </div>
    </div>
    <div class="form-group">
        <div class="row">
            <div class="col-sm-6">
                <label>Size:</label>
                <select class="form-control ope-input-small ope-select2" data-placeholder="Select a size">
                    <option>Large</option>
                    <option>Medium</option>
                    <option>Small</option>
                    <option>Xsmall</option>
                </select>
            </div>
            <div class="col-sm-6">
                <label>Width buttons:</label>
                <select class="form-control ope-input-small ope-select2" data-placeholder="Select a width">
                    <option>Auto</option>
                    <option>Fixed width</option>
                    <option>Full width</option>
                    <option>Columns</option>
                </select>
            </div>
        </div>
    </div>
    <div class="form-group has-fixed-width">
        <div class="row">
            <div class="col-sm-8">
                <label class="m-b-20">Set fixed width:</label>
                <div id="slider-fixed-width"></div>
            </div>
            <div class="col-sm-4 p-a-0">
                <label class="m-b-20"></label>
                <input type="number" id="input-fixed-width" class="form-control ope-input-xsmall" value="200" min="0" max="500" />
                <span class="text-label">px</span>
            </div>
        </div>
    </div>
    <div class="form-group has-fixed-width">
        <div class="row">
            <div class="col-sm-8">
                <label class="m-b-20">Set columns:</label>
                <div id="slider-columns"></div>
            </div>
            <div class="col-sm-4 p-a-0">
                <label class="m-b-20"></label>
                <input type="number" id="input-columns" class="form-control ope-input-xsmall" value="2" min="0" max="12" />
            </div>
        </div>
    </div>
    <div class="form-group">
        <label>Animation:</label>
        <select class="form-control ope-select2-search" data-placeholder="Select an animation">
            <option value="1" selected="">No animations</option>
            <option value="1">Pop out</option>
            <option value="1">Zoom out</option>
            <option value="1">Flip</option>
            <option value="1">Pop right</option>
            <option value="1">Pop left</option>
            <option value="1">Pop horizontal</option>
            <option value="1">Icon animation 1: Slide from right</option>
            <option value="1">Icon animation 2: Pop in</option>
            <option value="1">Icon animation 3: Fade in</option>
            <option value="1">Icon animation 4: Jump</option>
            <option value="1">Icon animation 5: Swing</option>
            <option value="1">Icon animation 6: Tada</option>
            <option value="1">Icon animation 7: Fade in from right</option>
            <option value="1">Icon animation 8: Fade in from left</option>
            <option value="1">Icon animation 9: Fade in from top</option>
            <option value="1">Icon animation 10: Fade in from bottom</option>
            <option value="1">Icon animation 11: Flash</option>
            <option value="1">Icon animation 12: Shake</option>
            <option value="1">Icon animation 13: Rubber band</option>
            <option value="1">Icon animation 14: Wooble</option>
            <option value="1">Button animation 1: Slide from right</option>
            <option value="1">Button animation 2: Pop in</option>
            <option value="1">Button animation 3: Fade in</option>
            <option value="1">Button animation 4: Jump</option>
            <option value="1">Button animation 5: Swing</option>
            <option value="1">Button animation 6: Tada</option>
            <option value="1">Button animation 7: Fade in from right</option>
            <option value="1">Button animation 8: Fade in from left</option>
            <option value="1">Button animation 9: Fade in from top</option>
            <option value="1">Button animation 10: Fade in from bottom</option>
            <option value="1">Button animation 11: Flash</option>
            <option value="1">Button animation 12: Shake</option>
            <option value="1">Button animation 13: Rubber band</option>
            <option value="1">Button animation 14: Wooble</option>
        </select>
    </div>
    <div class="form-group">
        <div class="row">
            <div class="col-sm-8">
                <label class="m-b-20">Network padding:</label>
                <div id="slider-padding"></div>
            </div>
            <div class="col-sm-4 p-a-0">
                <label class="m-b-20"></label>
                <input type="number" id="input-padding" class="form-control ope-input-xsmall" value="20" min="0" />
                <span class="text-label">px</span>
            </div>
        </div>
    </div>
</div>