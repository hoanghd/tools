<div class="ope-item-content">
    <fieldset>
        <legend>Post</legend>
        <div class="form-group">
            <label>Display position Content:</label>
            <select class="form-control ope-select2-tooltip" data-placeholder="Select a position">
                <option></option>
                <option rel="<?php echo OPE_ASSET_URI;?>/img/demo/01.png">Top</option>
                <option rel="<?php echo OPE_ASSET_URI;?>/img/demo/02.png">Bottom</option>
                <option rel="<?php echo OPE_ASSET_URI;?>/img/demo/03.png">Top & Bottom</option>
                <option rel="<?php echo OPE_ASSET_URI;?>/img/demo/04.png">Float Top</option>
                <option rel="<?php echo OPE_ASSET_URI;?>/img/demo/05.png">Float Top & Bottom</option>
                <option rel="<?php echo OPE_ASSET_URI;?>/img/demo/06.png">Post vertical float</option>
                <option rel="<?php echo OPE_ASSET_URI;?>/img/demo/07.png">Generate shortcode only</option>
            </select>
        </div>
        <div class="form-group">
            <label>Content align:</label>
            <select class="form-control ope-input-small ope-select2" data-placeholder="Select an align">
                <option></option>
                <option>Left</option>
                <option>Center</option>
                <option>Right</option>
            </select>
        </div>
    </fieldset>
    <fieldset>
        <legend>Woocommerce</legend>
        <div class="form-group">
            <div class="row">
                <div class="col-sm-8">
                    <label for="switch1">After product price:</label>
                </div>
                <div class="col-sm-4">
                    <label class="switch">
                        <input id="switch1" type="checkbox" class="switch-input">
                        <span class="switch-label" data-on="On" data-off="Off"></span>
                        <span class="switch-handle"></span>
                    </label>
                </div>
            </div>
        </div>
        <div class="form-group">
            <div class="row">
                <div class="col-sm-8">
                    <label for="switch2">On top of product:</label>
                </div>
                <div class="col-sm-4">
                    <label class="switch">
                        <input id="switch2" type="checkbox" class="switch-input">
                        <span class="switch-label" data-on="On" data-off="Off"></span>
                        <span class="switch-handle"></span>
                    </label>
                </div>
            </div>
        </div>
        <div class="form-group">
            <div class="row">
                <div class="col-sm-8">
                    <label for="switch3">At the bottom of product:</label>
                </div>
                <div class="col-sm-4">
                    <label class="switch">
                        <input id="switch3" type="checkbox" class="switch-input">
                        <span class="switch-label" data-on="On" data-off="Off"></span>
                        <span class="switch-handle"></span>
                    </label>
                </div>
            </div>
        </div>
    </fieldset>
    <div class="form-group">
        <label>Display position Screen:</label>
        <select class="form-control ope-select2-tooltip" multiple="true" data-placeholder="Select a position">
            <option></option>
            <option rel="<?php echo OPE_ASSET_URI;?>/img/demo/01.png">Sidebar left</option>
            <option rel="<?php echo OPE_ASSET_URI;?>/img/demo/02.png">Sidebar right</option>
            <option rel="<?php echo OPE_ASSET_URI;?>/img/demo/03.png">Popup</option>
            <option rel="<?php echo OPE_ASSET_URI;?>/img/demo/04.png">Fly in</option>
            <option rel="<?php echo OPE_ASSET_URI;?>/img/demo/05.png">Top bar</option>
            <option rel="<?php echo OPE_ASSET_URI;?>/img/demo/06.png">Bottom bar</option>
            <option rel="<?php echo OPE_ASSET_URI;?>/img/demo/07.png">On media</option>
            <option rel="<?php echo OPE_ASSET_URI;?>/img/demo/08.png">Full screen hero share</option>
            <option rel="<?php echo OPE_ASSET_URI;?>/img/demo/09.png">Post share bar</option>
        </select>
    </div>
</div>