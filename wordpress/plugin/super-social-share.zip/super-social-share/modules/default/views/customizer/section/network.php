<a href="javascript:void(0);" class="ope-item-heading">Manage Network</a>
<div class="ope-item-content customizer-network">
    <button type="button" class="ope-btn ope-btn-add-networks ope-btn-add">Add networks</button>
    <ul class="ope-link-list ope-template-icon ope-manage-networks-list-demo ope-networks-list"></ul>
</div>
<!-- Dialog Manage Network -->
<div id="ope-dialog-manage-network" class="customizer-network-dialog" title="Add network">
    <div class="ope-dialog-content">
        <ul class="ope-link-list ope-template-icon ope-template-name ope-networks-dialog"></ul>
    </div>
    <div class="ope-dialog-footer">
        <button class="ope-btn"><i class="ion-android-done"></i> &nbsp; Close</button>
    </div>
</div>
<script type="text/template" name="Network">
    <% if( !_.isEmpty( row ) ) { %>
        <a href="javascript:void(0);">
            <i class="ope-social-icon"></i>
        </a>
        <input type="text" class="form-control ope-input-name" value="<%=row.name%>">
        <div class="ope-social-action">
            <a href="javascript:void(0);" class="ope-social-drag"><i class="ion-ios-drag"></i></a>
            <a href="javascript:void(0);" class="ope-social-delete"><i class="ion-ios-close-empty ope-btn-destroy"></i></a>
        </div>
    <% } %>
</script>
<script type="text/template" name="Social">
    <% if( !_.isEmpty( row ) ) { %>
        <a href="javascript:void(0);">
            <i class="ope-social-icon"></i>
            <div class="ope-social-label">
                <div class="ope-social-name"><%=row.name%></div>
                <div class="ope-social-count"><span><%=row.num%></span></div>
            </div>
        </a>
    <% } %>
</script>

