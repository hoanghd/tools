<a href="javascript:void(0);" class="ope-item-heading">Manage Network</a>
<div class="ope-item-content customizer-network">
    <button type="button" class="ope-btn ope-btn-add-networks ope-btn-add">Add networks</button>
    <ul class="ope-link-list ope-template-icon ope-manage-networks-list-demo ope-networks-list"></ul>
    <div class="form-group">
        <div class="form-group">
            <label>More button:</label>
            <div fn="select2" data-model="model" data-name="button"></div>
        </div>
        <div class="form-group">
            <label>More button icon:</label>
            <div fn="select2" data-model="model" data-name="icon"></div>
        </div>
        <div class="form-group">
            <div class="row">
                <div class="col-sm-8">
                    <label class="m-b-20">Display network max:</label>
                    <div fn="slider" data-model="model" data-name="max_display" data-html-options='{"min": 0, "step": 1, "range": "min", "stop": "slideStop", "max":"fn:[this.model|cnt]"}'></div>
                </div>
                <div class="col-sm-4 p-a-0">
                    <label class="m-b-20"></label>
                    <div fn="numberField" data-model="model" data-name="max_display" data-html-options='{"class": "form-control ope-input-xsmall", "min": 0, "max":"fn:[this.model|cnt]"}'></div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Dialog Manage Network -->
<div id="ope-dialog-manage-network" class="customizer-network-dialog" title="Add network">
    <div class="ope-dialog-content">
        <ul class="ope-link-list ope-template-icon ope-template-name ope-networks-dialog"></ul>
    </div>
    <div class="ope-dialog-footer">
        <button class="ope-btn"><i class="ion-android-done"></i> &nbsp; Close</button>
    </div>
</div>
<script type="text/template" name="Network">
    <% if( !_.isEmpty( row ) ) { %>
        <a href="javascript:void(0);">
            <i class="ope-social-icon"></i>
        </a>
        <input type="text" class="form-control ope-input-name" value="<%=row.name%>">
        <div class="ope-social-action">
            <a href="javascript:void(0);" class="ope-social-drag"><i class="ion-ios-drag"></i></a>
            <a href="javascript:void(0);" class="ope-social-delete"><i class="ion-ios-close-empty ope-btn-destroy"></i></a>
        </div>
    <% } %>
</script>
<script type="text/template" name="Social">
    <% if( !_.isEmpty( row ) ) { %>
        <a href="javascript:void(0);">
            <i class="ope-social-icon"></i>
            <div class="ope-social-label">
                <div class="ope-social-name"><%=row.name%></div>
                <div class="ope-social-count"><span><%=row.num%></span></div>
            </div>
        </a>
    <% } %>
</script>

