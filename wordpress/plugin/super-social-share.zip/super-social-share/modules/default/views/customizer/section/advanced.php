<div class="ope-item-content">
    <div class="form-group">
        <label>Customize css:</label>
        <textarea class="form-control" rows="5"></textarea>
    </div>
</div>