<div class="ope-advanced-setting ope-custom-jquery-ui ope-customizer-menu">
    <div class="ope-advanced-wrap">
        <?php $this->render(dirname(__FILE__) . '/section/sidebar.php');?>
        <div class="ope-advanced-sidebar">
            <div class="ope-sidebar-wrap">
                <ul class="ope-option-list">
                    <li>
                        <a href="javascript:void(0);" class="ope-item-heading">Manage Network</a>
                        <?php $this->render(dirname(__FILE__) . '/section/network.php');?>
                    </li>
                    <li>
                        <a href="javascript:void(0);" class="ope-item-heading">Template</a>
                        <?php $this->render(dirname(__FILE__) . '/section/template.php');?>
                    </li>
                    <li style="display:none;">
                        <a href="javascript:void(0);" class="ope-item-heading">Position</a>
                        <?php $this->render(dirname(__FILE__) . '/section/template.php');?>
                    </li>
                    <li>
                        <a href="javascript:void(0);" class="ope-item-heading">Style</a>
                        <?php $this->render(dirname(__FILE__) . '/section/style.php');?>
                    </li>
                    <li>
                        <a href="javascript:void(0);" class="ope-item-heading">Advanced settings</a>
                        <?php $this->render(dirname(__FILE__) . '/section/advanced.php');?>
                    </li>
                </ul>
            </div>
        </div>
        <div class="ope-advanced-content">
            <div class="ope-screen-live-preview">
                <div class="ope-screen-live-preview-wrap">
                    <iframe onload="Customizer.Preview.load();" src="<?php echo admin_url('admin.php?page=ope-customizer-view');?>" style="visibility: visible;"></iframe>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $this->render(dirname(__FILE__) . '/section/dialog.php');?>