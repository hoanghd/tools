<div class="ope-advanced-setting ope-custom-jquery-ui customizer-menu">
    <div class="ope-advanced-wrap">
        <?php $this->render(dirname(__FILE__) . '/section/sidebar.php');?>
        <div class="ope-advanced-sidebar">
            <div class="ope-sidebar-wrap">
                <ul class="ope-option-list">
                    <li class="active">
                        <?php $this->render(dirname(__FILE__) . '/section/network.php');?>
                    </li>
                    <li>
                        <a href="javascript:void(0);" class="ope-item-heading">Template</a>
                        <div class="ope-item-content">
                            <div class="form-group">
                                <label>Template network:</label>
                                <select class="ope-template-list-demo form-control ope-select2-search" data-placeholder="Select a template network">
                                    <option value=""></option>
                                    <option value="3">Icon - Name</option>
                                    <option value="1">Icon - Name - Counter</option>
                                    <option value="2">Icon - Name - Total Counter</option>
                                    <option value="2">Icon - Name - Counter - Total Counter</option>
                                    <option value="4">Icon - Counter</option>
                                    <option value="4">Icon</option>
                                    <option value="4">Name - Vertical</option>
                                    <option value="4">Icon - Name - Vertical</option>
                                </select>
                            </div>
                            <div class="form-group has-counter">
                                <label>Counter Position:</label>
                                <select class="form-control ope-input-small ope-select2">
                                    <option>Top</option>
                                    <option>Left</option>
                                    <option>Right</option>
                                    <option>Bottom</option>
                                </select>
                            </div>
                            <div class="form-group has-counter">
                                <div class="row">
                                    <div class="col-sm-8">
                                        <label class="m-b-20">Set Counter min:</label>
                                        <div id="slider-counter-min"></div>
                                    </div>
                                    <div class="col-sm-4 p-a-0">
                                        <label class="m-b-20"></label>
                                        <input type="number" id="input-counter-min" class="form-control ope-input-xsmall" value="50" min="0" max="1000" />
                                    </div>
                                </div>
                            </div>
                            <div class="form-group has-total-counter">
                                <label>Total Counter Position:</label>
                                <select class="form-control ope-input-small ope-select2">
                                    <option>Top</option>
                                    <option>Left</option>
                                    <option>Right</option>
                                    <option>Bottom</option>
                                </select>
                            </div>
                            <div class="form-group has-total-counter">
                                <div class="row">
                                    <div class="col-sm-8">
                                        <label class="m-b-20">Set Total Counter min:</label>
                                        <div id="slider-total-counter-min"></div>
                                    </div>
                                    <div class="col-sm-4 p-a-0">
                                        <label class="m-b-20"></label>
                                        <input type="number" id="input-total-counter-min" class="form-control ope-input-xsmall" value="200" min="0" max="1000" />
                                    </div>
                                </div>
                            </div>
                            <div class="form-group">
                                <label>Counter update mode:</label>
                                <select class="form-control ope-input-medium ope-select2">
                                    <option>Real time share</option>
                                    <option>Cache share</option>
                                </select>
                            </div>
                        </div>
                    </li>
                    <li>
                        <a href="javascript:void(0);" class="ope-item-heading">Position</a>
                        <div class="ope-item-content">
                            <fieldset>
                                <legend>Post</legend>
                                <div class="form-group">
                                    <label>Display position Content:</label>
                                    <select class="form-control ope-select2-tooltip" data-placeholder="Select a position">
                                        <option></option>
                                        <option data-img="<?php echo OPE_ASSET_URI;?>/img/demo/01.png">Top</option>
                                        <option data-img="<?php echo OPE_ASSET_URI;?>/img/demo/02.png">Bottom</option>
                                        <option data-img="<?php echo OPE_ASSET_URI;?>/img/demo/03.png">Top & Bottom</option>
                                        <option data-img="<?php echo OPE_ASSET_URI;?>/img/demo/04.png">Float Top</option>
                                        <option data-img="<?php echo OPE_ASSET_URI;?>/img/demo/05.png">Float Top & Bottom</option>
                                        <option data-img="<?php echo OPE_ASSET_URI;?>/img/demo/06.png">Post vertical float</option>
                                        <option data-img="<?php echo OPE_ASSET_URI;?>/img/demo/07.png">Manual display with shortcode only</option>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label>Content align:</label>
                                    <select class="form-control ope-input-small ope-select2" data-placeholder="Select an align">
                                        <option></option>
                                        <option>Left</option>
                                        <option>Center</option>
                                        <option>Right</option>
                                    </select>
                                </div>
                            </fieldset>
                            <fieldset>
                                <legend>Woocommerce</legend>
                                <div class="form-group">
                                    <div class="row">
                                        <div class="col-sm-8">
                                            <label for="switch1">After product price:</label>
                                        </div>
                                        <div class="col-sm-4">
                                            <label class="switch">
                                                <input id="switch1" type="checkbox" class="switch-input">
                                                <span class="switch-label" data-on="On" data-off="Off"></span>
                                                <span class="switch-handle"></span>
                                            </label>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="row">
                                        <div class="col-sm-8">
                                            <label for="switch2">On top of product:</label>
                                        </div>
                                        <div class="col-sm-4">
                                            <label class="switch">
                                                <input id="switch2" type="checkbox" class="switch-input">
                                                <span class="switch-label" data-on="On" data-off="Off"></span>
                                                <span class="switch-handle"></span>
                                            </label>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="row">
                                        <div class="col-sm-8">
                                            <label for="switch3">At the bottom of product:</label>
                                        </div>
                                        <div class="col-sm-4">
                                            <label class="switch">
                                                <input id="switch3" type="checkbox" class="switch-input">
                                                <span class="switch-label" data-on="On" data-off="Off"></span>
                                                <span class="switch-handle"></span>
                                            </label>
                                        </div>
                                    </div>
                                </div>
                            </fieldset>
                            <div class="form-group">
                                <label>Display position Screen:</label>
                                <select class="form-control ope-select2-tooltip" multiple="true" data-placeholder="Select a position">
                                    <option></option>
                                    <option data-img="<?php echo OPE_ASSET_URI;?>/img/demo/01.png">Sidebar left</option>
                                    <option data-img="<?php echo OPE_ASSET_URI;?>/img/demo/02.png">Sidebar right</option>
                                    <option data-img="<?php echo OPE_ASSET_URI;?>/img/demo/03.png">Popup</option>
                                    <option data-img="<?php echo OPE_ASSET_URI;?>/img/demo/04.png">Fly in</option>
                                    <option data-img="<?php echo OPE_ASSET_URI;?>/img/demo/05.png">Top bar</option>
                                    <option data-img="<?php echo OPE_ASSET_URI;?>/img/demo/06.png">Bottom bar</option>
                                    <option data-img="<?php echo OPE_ASSET_URI;?>/img/demo/07.png">On media</option>
                                    <option data-img="<?php echo OPE_ASSET_URI;?>/img/demo/08.png">Full screen hero share</option>
                                    <option data-img="<?php echo OPE_ASSET_URI;?>/img/demo/09.png">Post share bar</option>
                                </select>
                            </div>
                        </div>
                    </li>
                    <li>
                        <a href="#" class="ope-item-heading">Style</a>
                        <div class="ope-item-content">
                            <div class="form-group">
                                <div class="row">
                                    <div class="col-sm-6">
                                        <label>Style:</label>
                                        <select class="form-control ope-input-small ope-select2" data-placeholder="Select a style">
                                            <option>Flat</option>
                                            <option>3D</option>
                                            <option>Outlined</option>
                                        </select>
                                    </div>
                                    <div class="col-sm-6">
                                        <label>Shape:</label>
                                        <select class="form-control ope-input-small ope-select2" data-placeholder="Select a shape">
                                            <option>Rounded</option>
                                            <option>Squared</option>
                                            <option>Circled</option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="row">
                                    <div class="col-sm-6">
                                        <label>Size:</label>
                                        <select class="form-control ope-input-small ope-select2" data-placeholder="Select a size">
                                            <option>Large</option>
                                            <option>Medium</option>
                                            <option>Small</option>
                                            <option>Xsmall</option>
                                        </select>
                                    </div>
                                    <div class="col-sm-6">
                                        <label>Width buttons:</label>
                                        <select class="form-control ope-input-small ope-select2" data-placeholder="Select a width">
                                            <option>Auto</option>
                                            <option>Fixed width</option>
                                            <option>Full width</option>
                                            <option>Columns</option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div class="form-group has-fixed-width">
                                <div class="row">
                                    <div class="col-sm-8">
                                        <label class="m-b-20">Set fixed width:</label>
                                        <div id="slider-fixed-width"></div>
                                    </div>
                                    <div class="col-sm-4 p-a-0">
                                        <label class="m-b-20"></label>
                                        <input type="number" id="input-fixed-width" class="form-control ope-input-xsmall" value="200" min="0" max="500" />
                                        <span class="text-label">px</span>
                                    </div>
                                </div>
                            </div>
                            <div class="form-group has-fixed-width">
                                <div class="row">
                                    <div class="col-sm-8">
                                        <label class="m-b-20">Set columns:</label>
                                        <div id="slider-columns"></div>
                                    </div>
                                    <div class="col-sm-4 p-a-0">
                                        <label class="m-b-20"></label>
                                        <input type="number" id="input-columns" class="form-control ope-input-xsmall" value="2" min="0" max="12" />
                                    </div>
                                </div>
                            </div>
                            <div class="form-group">
                                <label>Animation:</label>
                                <select class="form-control ope-select2-search" data-placeholder="Select an animation">
                                    <option value="1" selected="">No animations</option>
                                    <option value="1">Pop out</option>
                                    <option value="1">Zoom out</option>
                                    <option value="1">Flip</option>
                                    <option value="1">Pop right</option>
                                    <option value="1">Pop left</option>
                                    <option value="1">Pop horizontal</option>
                                    <option value="1">Icon animation 1: Slide from right</option>
                                    <option value="1">Icon animation 2: Pop in</option>
                                    <option value="1">Icon animation 3: Fade in</option>
                                    <option value="1">Icon animation 4: Jump</option>
                                    <option value="1">Icon animation 5: Swing</option>
                                    <option value="1">Icon animation 6: Tada</option>
                                    <option value="1">Icon animation 7: Fade in from right</option>
                                    <option value="1">Icon animation 8: Fade in from left</option>
                                    <option value="1">Icon animation 9: Fade in from top</option>
                                    <option value="1">Icon animation 10: Fade in from bottom</option>
                                    <option value="1">Icon animation 11: Flash</option>
                                    <option value="1">Icon animation 12: Shake</option>
                                    <option value="1">Icon animation 13: Rubber band</option>
                                    <option value="1">Icon animation 14: Wooble</option>
                                    <option value="1">Button animation 1: Slide from right</option>
                                    <option value="1">Button animation 2: Pop in</option>
                                    <option value="1">Button animation 3: Fade in</option>
                                    <option value="1">Button animation 4: Jump</option>
                                    <option value="1">Button animation 5: Swing</option>
                                    <option value="1">Button animation 6: Tada</option>
                                    <option value="1">Button animation 7: Fade in from right</option>
                                    <option value="1">Button animation 8: Fade in from left</option>
                                    <option value="1">Button animation 9: Fade in from top</option>
                                    <option value="1">Button animation 10: Fade in from bottom</option>
                                    <option value="1">Button animation 11: Flash</option>
                                    <option value="1">Button animation 12: Shake</option>
                                    <option value="1">Button animation 13: Rubber band</option>
                                    <option value="1">Button animation 14: Wooble</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <div class="row">
                                    <div class="col-sm-8">
                                        <label class="m-b-20">Network padding:</label>
                                        <div id="slider-padding"></div>
                                    </div>
                                    <div class="col-sm-4 p-a-0">
                                        <label class="m-b-20"></label>
                                        <input type="number" id="input-padding" class="form-control ope-input-xsmall" value="20" min="0" />
                                        <span class="text-label">px</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </li>
                    <li>
                        <a href="javascript:void(0);" class="ope-item-heading">Advanced settings</a>
                        <div class="ope-item-content">
                            <div class="form-group">
                                <label>Customize css:</label>
                                <textarea class="form-control" rows="5"></textarea>
                            </div>
                        </div>
                    </li>
                </ul>
            </div>
        </div>
        <div class="ope-advanced-content">
            <div class="ope-screen-live-preview">
                <div class="ope-screen-live-preview-wrap">
                	<iframe onload="Customizer.Preview.load();" src="<?php echo admin_url('admin.php?page=ope-customizer-view');?>" style="visibility: visible;"></iframe>
                    <div class="ope-demo-content" style="display:none;">
                        <!-- STYLE DEFAULT -->
                        <ul class="ope-link-list ope-template-icon ope-template-name ope-template-count">
                            <li class="ope-social-link ope-social-facebook">
                                <a href="javascript:void(0);">
                                    <i class="ope-social-icon"></i>
                                    <div class="ope-social-label">
                                        <div class="ope-social-name">Facebook</div>
                                        <div class="ope-social-count"><span>5</span></div>
                                    </div>
                                </a>
                            </li>
                            <li class="ope-social-link ope-social-twitter">
                                <a href="javascript:void(0);">
                                    <i class="ope-social-icon"></i>
                                    <div class="ope-social-label">
                                        <div class="ope-social-name">Twitter</div>
                                        <div class="ope-social-count"><span>12k</span></div>
                                    </div>
                                </a>
                            </li>
                            <li class="ope-social-link ope-social-google-plus">
                                <a href="javascript:void(0);">
                                    <i class="ope-social-icon"></i>
                                    <div class="ope-social-label">
                                        <div class="ope-social-name">Google plus</div>
                                        <div class="ope-social-count"><span>30</span></div>
                                    </div>
                                </a>
                            </li>
                            <li class="ope-social-link ope-social-pinterest">
                                <a href="javascript:void(0);">
                                    <i class="ope-social-icon"></i>
                                    <div class="ope-social-label">
                                        <div class="ope-social-name">Pinterest</div>
                                        <div class="ope-social-count"><span>165</span></div>
                                    </div>
                                </a>
                            </li>
                            <li class="ope-social-link ope-social-instagram">
                                <a href="javascript:void(0);">
                                    <i class="ope-social-icon"></i>
                                    <div class="ope-social-label">
                                        <div class="ope-social-name">Instagram</div>
                                        <div class="ope-social-count"><span>75</span></div>
                                    </div>
                                </a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>