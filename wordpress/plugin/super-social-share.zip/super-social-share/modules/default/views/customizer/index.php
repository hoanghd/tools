<div class="ope-advanced-setting ope-custom-jquery-ui customizer-menu">
    <div class="ope-advanced-wrap">
        <?php $this->render(dirname(__FILE__) . '/section/sidebar.php');?>
        <div class="ope-advanced-sidebar">
            <div class="ope-sidebar-wrap">
                <ul class="ope-option-list">
                    <li class="active">
                        <?php $this->render(dirname(__FILE__) . '/section/network.php');?>
                    </li>
                    <li>
                        <a href="javascript:void(0);" class="ope-item-heading">Template</a>
                        <div class="ope-item-content">
                            <select class="ope-template-list-demo form-control">
                                <option value=""></option>
                                <option value="1">Icon - Name - Count</option>
                                <option value="2">Icon - Name</option>
                                <option value="3">Icon - Count</option>
                            </select>
                        </div>
                    </li>
                    <li>
                        <a href="javascript:void(0);" class="ope-item-heading">Style</a>
                        <div class="ope-item-content">
                            <ul class="list-inline ope-style-list-demo">
                                <li class="active">
                                    <span>Flat</span>
                                    <a href="javascript:void(0);" class="ope-item-style ope-style-flat"></a>
                                </li>
                                <li>
                                    <span>3D</span>
                                    <a href="javascript:void(0);" class="ope-item-style ope-style-3d"></a>
                                </li>
                                <li>
                                    <span>Outline</span>
                                    <a href="javascript:void(0);" class="ope-item-style ope-style-outline"></a>
                                </li>
                            </ul>
                        </div>
                    </li>
                    <li>
                        <a href="javascript:void(0);" class="ope-item-heading">Shape</a>
                        <div class="ope-item-content">
                            <ul class="list-inline ope-shape-list-demo">
                                <li class="active">
                                    <span>Rounded</span>
                                    <a href="javascript:void(0);" class="ope-item-shape ope-shape-rounded"></a>
                                </li>
                                <li>
                                    <span>Squared</span>
                                    <a href="javascript:void(0);" class="ope-item-shape ope-shape-squared"></a>
                                </li>
                                <li>
                                    <span>Circled</span>
                                    <a href="javascript:void(0);" class="ope-item-shape ope-shape-circled"></a>
                                </li>
                            </ul>
                        </div>
                    </li>
                    <li>
                        <a href="javascript:void(0);" class="ope-item-heading">Position</a>
                        <div class="ope-item-content">
                            <ul class="list-inline ope-position-list-demo">
                                <li class="active">
                                    <span>Left screen</span>
                                    <a href="javascript:void(0);" class="ope-item-pos ope-pos-screen-left">
                                        <span class="ope-pos-social"></span>
                                    </a>
                                </li>
                                <li>
                                    <span>Right screen</span>
                                    <a href="javascript:void(0);" class="ope-item-pos ope-pos-screen-right">
                                        <span class="ope-pos-social"></span>
                                    </a>
                                </li>
                                <li>
                                    <span>Top screen</span>
                                    <a href="javascript:void(0);" class="ope-item-pos ope-pos-screen-top">
                                        <span class="ope-pos-social"></span>
                                    </a>
                                </li>
                                <li>
                                    <span>Bottom screen</span>
                                    <a href="javascript:void(0);" class="ope-item-pos ope-pos-screen-bottom">
                                        <span class="ope-pos-social"></span>
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </li>
                    <li>
                        <a href="javascript:void(0);" class="ope-item-heading">Design Option</a>
                        <div class="ope-item-content">
                            <div class="ope-item-option">
                                <div class="ope-item-option-title">Slider:</div>
                                <div id="slider-padding"></div>
                            </div>
                            <div class="ope-item-option">
                                <div class="ope-item-option-title">Text Field:</div>
                                <input type="text" class="form-control" placeholder="Enter your name" />
                            </div>
                            <div class="ope-item-option">
                                <div class="ope-item-option-title">Number Field:</div>
                                <input type="number" class="form-control ope-input-xsmall" value="2" />
                            </div>
                            <div class="ope-item-option">
                                <div class="ope-item-option-title">Range Field:</div>
                                <input type="range" class="form-control ope-input-medium" />
                            </div>
                            <div class="ope-item-option">
                                <div class="ope-item-option-title">Textarea:</div>
                                <textarea class="form-control" rows="3" placeholder="Enter your content"></textarea>
                            </div>
                        </div>
                    </li>
                </ul>
            </div>
        </div>
        <div class="ope-advanced-content">
            <div class="ope-screen-live-preview">
                <div class="ope-screen-live-preview-wrap">
                	<iframe onload="Customizer.Preview.load();" src="<?php echo admin_url('admin.php?page=ope-customizer-view');?>" style="visibility: visible;"></iframe>
                    <div class="ope-demo-content" style="display:none;">
                        <!-- STYLE DEFAULT -->
                        <ul class="ope-link-list ope-template-icon ope-template-name ope-template-count">
                            <li class="ope-social-link ope-social-facebook">
                                <a href="javascript:void(0);">
                                    <i class="ope-social-icon"></i>
                                    <div class="ope-social-label">
                                        <div class="ope-social-name">Facebook</div>
                                        <div class="ope-social-count"><span>5</span></div>
                                    </div>
                                </a>
                            </li>
                            <li class="ope-social-link ope-social-twitter">
                                <a href="javascript:void(0);">
                                    <i class="ope-social-icon"></i>
                                    <div class="ope-social-label">
                                        <div class="ope-social-name">Twitter</div>
                                        <div class="ope-social-count"><span>12k</span></div>
                                    </div>
                                </a>
                            </li>
                            <li class="ope-social-link ope-social-google-plus">
                                <a href="javascript:void(0);">
                                    <i class="ope-social-icon"></i>
                                    <div class="ope-social-label">
                                        <div class="ope-social-name">Google plus</div>
                                        <div class="ope-social-count"><span>30</span></div>
                                    </div>
                                </a>
                            </li>
                            <li class="ope-social-link ope-social-pinterest">
                                <a href="javascript:void(0);">
                                    <i class="ope-social-icon"></i>
                                    <div class="ope-social-label">
                                        <div class="ope-social-name">Pinterest</div>
                                        <div class="ope-social-count"><span>165</span></div>
                                    </div>
                                </a>
                            </li>
                            <li class="ope-social-link ope-social-instagram">
                                <a href="javascript:void(0);">
                                    <i class="ope-social-icon"></i>
                                    <div class="ope-social-label">
                                        <div class="ope-social-name">Instagram</div>
                                        <div class="ope-social-count"><span>75</span></div>
                                    </div>
                                </a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>