<!-- Dialog Manage Network -->
<div id="ope-dialog-manage-network" class="ope-customizer-network-dialog" title="Add network">
    <div class="ope-dialog-content">
        <ul class="ope-link-list ope-template-icon ope-template-name ope-networks-dialog"></ul>
    </div>
    <div class="ope-dialog-footer">
        <button class="ope-btn"><i class="ion-android-done"></i> &nbsp; Close</button>
    </div>
</div>