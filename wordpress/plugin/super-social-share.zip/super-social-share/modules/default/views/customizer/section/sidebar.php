<div class="ope-advanced-sub-sidebar">
    <ul class="list-unstyled ope-sub-sidebar-action">
        <li>
            <a href="javascript:void(0);" class="ope-action-collapse">
                <i class="fa fa-arrows-h"></i>
            </a>
        </li>
        <li>
            <a href="javascript:void(0);">
                <i class="ion-monitor"></i>
            </a>
        </li>
        <li>
            <a href="javascript:void(0);">
                <i class="fa fa-save"></i>
            </a>
        </li>
        <li>
            <a href="javascript:void(0);">
                <i class="fa fa-copy"></i>
            </a>
        </li>
        <li>
            <a href="javascript:void(0);">
                <i class="ion-refresh"></i>
            </a>
        </li>
        <li>
            <a href="javascript:void(0);">
                <i class="ion-close-round"></i>
            </a>
        </li>
    </ul>
    <ul class="list-unstyled ope-sub-sidebar-action ope-bottom">
        <li>
            <a href="#">
                <i class="ion-help-circled"></i>
            </a>
        </li>
    </ul>
</div>