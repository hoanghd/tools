<div class="ope-advanced-sub-sidebar">
    <ul class="list-unstyled ope-sub-sidebar-action">
        <li>
            <a href="javascript:void(0);">
                <i class="ion-arrow-resize"></i>
            </a>
        </li>
        <li>
            <a href="javascript:void(0);">
                <i class="ion-monitor"></i>
            </a>
        </li>
        <li>
            <a href="javascript:void(0);">
                <i class="ion-plus-round"></i>
            </a>
        </li>
        <li>
            <a href="javascript:void(0);">
                <i class="ion-archive"></i>
            </a>
        </li>
        <li>
            <a href="javascript:void(0);">
                <i class="ion-close-round"></i>
            </a>
        </li>
    </ul>
</div>