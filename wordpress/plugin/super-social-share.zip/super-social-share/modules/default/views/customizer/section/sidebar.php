<div class="ope-advanced-sub-sidebar">
    <ul class="list-unstyled ope-sub-sidebar-action">
        <li>
            <a href="javascript:void(0);" class="ope-action-collapse tooltip" title="Full screen">
                <i class="fa fa-arrows-h"></i>
            </a>
        </li>
        <li>
            <a href="javascript:void(0);" class="tooltip" title="Responsive mobile">
                <i class="ion-monitor"></i>
            </a>
        </li>
        <li>
            <a href="javascript:void(0);" class="tooltip" title="Save style">
                <i class="fa fa-save"></i>
            </a>
        </li>
        <li>
            <a href="javascript:void(0);" class="tooltip" title="Save as style">
                <i class="fa fa-copy"></i>
            </a>
        </li>
        <li>
            <a href="javascript:void(0);" class="tooltip" title="Reset style">
                <i class="ion-refresh"></i>
            </a>
        </li>
        <li>
            <a href="javascript:void(0);" class="tooltip" title="Exit live customizer">
                <i class="ion-close-round"></i>
            </a>
        </li>
    </ul>
    <ul class="list-unstyled ope-sub-sidebar-action ope-bottom">
        <li>
            <a href="#" class="tooltip" title="Introduction">
                <i class="ion-help-circled"></i>
            </a>
        </li>
    </ul>
</div>