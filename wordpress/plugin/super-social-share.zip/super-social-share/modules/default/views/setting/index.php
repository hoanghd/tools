<div class="wrap">
  <h1>Edit Post Type<a class="add-new-h2" href="">Add New</a></h1>
  <div id="poststuff">
    <div id="post-body" class="metabox-holder columns-2">
      <div id="post-body-content" class="postbox">
        <h2 class="hndle ui-sortable-handle"><span>Featured Image</span></h2>
        <div class="inside">
          <div class="form-wrap">
            <div class="form-field term-slug-wrap">
              <label for="tag-slug">Slug</label>
              <input type="text" size="40" value="" id="tag-slug" name="slug">
              <p>The “slug” is the URL-friendly version of the name. It is usually all lowercase and contains only letters, numbers, and hyphens.</p>
            </div>
            <div class="form-field term-parent-wrap">
              <label for="parent">Parent</label>
              <select class="postform" id="parent" name="parent">
                <option value="-1">None</option>
                <option value="1" class="level-0">Uncategorized</option>
              </select>
              <p>Categories, unlike tags, can have a hierarchy. You might have a Jazz category, and under that have children categories for Bebop and Big Band. Totally optional.</p>
            </div>
            <div class="form-field term-description-wrap">
              <label for="tag-description">Description</label>
              <textarea cols="40" rows="5" id="tag-description" name="description"></textarea>
              <p>The description is not prominent by default; however, some themes may show it.</p>
            </div>
          </div>
        </div>
      </div>
      <div class="postbox-container" id="postbox-container-1">
        <div class="meta-box-sortables ui-sortable">
          <div class="postbox " id="submitdiv">
            <button aria-expanded="true" class="handlediv button-link" type="button"><span class="screen-reader-text">Toggle panel: Publish</span><span aria-hidden="true" class="toggle-indicator"></span></button>
            <h2 class="hndle ui-sortable-handle"><span>Publish</span></h2>
            <div class="inside">
              <div id="submitpost" class="submitbox">
                <div id="minor-publishing">
                  <div style="display:none;">
                    <p class="submit">
                      <input type="submit" value="Save" class="button" id="save" name="save">
                    </p>
                  </div>
                  <div id="minor-publishing-actions">
                    <div id="save-action">
                      <input type="submit" class="button" value="Save Draft" id="save-post" name="save">
                      <span class="spinner"></span> </div>
                    <div id="preview-action"> <a id="post-preview" target="wp-preview-18" href="http://plugin.dev/?page_id=18&amp;preview=true" class="preview button">Preview</a>
                      <input type="hidden" value="" id="wp-preview" name="wp-preview">
                    </div>
                    <div class="clear"></div>
                  </div>
                  <!-- #minor-publishing-actions -->
                  
                  <div id="misc-publishing-actions">
                    <div class="misc-pub-section misc-pub-post-status">
                      <label for="post_status">Status:</label>
                      <span id="post-status-display"> Draft</span> <a class="edit-post-status hide-if-no-js" href="#post_status"><span aria-hidden="true">Edit</span> <span class="screen-reader-text">Edit status</span></a>
                      <div class="hide-if-js" id="post-status-select">
                        <input type="hidden" value="draft" id="hidden_post_status" name="hidden_post_status">
                        <select id="post_status" name="post_status">
                          <option value="pending">Pending Review</option>
                          <option value="draft" selected="selected">Draft</option>
                        </select>
                        <a class="save-post-status hide-if-no-js button" href="#post_status">OK</a> <a class="cancel-post-status hide-if-no-js button-cancel" href="#post_status">Cancel</a> </div>
                    </div>
                    <!-- .misc-pub-section -->
                    
                    <div id="visibility" class="misc-pub-section misc-pub-visibility"> Visibility: <span id="post-visibility-display">Public</span> <a class="edit-visibility hide-if-no-js" href="#visibility"><span aria-hidden="true">Edit</span> <span class="screen-reader-text">Edit visibility</span></a>
                      <div class="hide-if-js" id="post-visibility-select">
                        <input type="hidden" value="" id="hidden-post-password" name="hidden_post_password">
                        <input type="hidden" value="public" id="hidden-post-visibility" name="hidden_post_visibility">
                        <input type="radio" checked="checked" value="public" id="visibility-radio-public" name="visibility">
                        <label class="selectit" for="visibility-radio-public">Public</label>
                        <br>
                        <input type="radio" value="password" id="visibility-radio-password" name="visibility">
                        <label class="selectit" for="visibility-radio-password">Password protected</label>
                        <br>
                        <span id="password-span">
                        <label for="post_password">Password:</label>
                        <input type="text" maxlength="20" value="" id="post_password" name="post_password">
                        <br>
                        </span>
                        <input type="radio" value="private" id="visibility-radio-private" name="visibility">
                        <label class="selectit" for="visibility-radio-private">Private</label>
                        <br>
                        <p> <a class="save-post-visibility hide-if-no-js button" href="#visibility">OK</a> <a class="cancel-post-visibility hide-if-no-js button-cancel" href="#visibility">Cancel</a> </p>
                      </div>
                    </div>
                    <!-- .misc-pub-section -->
                    
                    <div class="misc-pub-section curtime misc-pub-curtime"> <span id="timestamp"> Publish <b>immediately</b></span> <a class="edit-timestamp hide-if-no-js" href="#edit_timestamp"><span aria-hidden="true">Edit</span> <span class="screen-reader-text">Edit date and time</span></a>
                      <fieldset class="hide-if-js" id="timestampdiv">
                        <legend class="screen-reader-text">Date and time</legend>
                        <div class="timestamp-wrap">
                          <label><span class="screen-reader-text">Month</span>
                            <select name="mm" id="mm">
                              <option data-text="Jan" value="01">01-Jan</option>
                              <option data-text="Feb" value="02">02-Feb</option>
                              <option data-text="Mar" value="03">03-Mar</option>
                              <option data-text="Apr" value="04">04-Apr</option>
                              <option data-text="May" value="05">05-May</option>
                              <option data-text="Jun" value="06">06-Jun</option>
                              <option selected="selected" data-text="Jul" value="07">07-Jul</option>
                              <option data-text="Aug" value="08">08-Aug</option>
                              <option data-text="Sep" value="09">09-Sep</option>
                              <option data-text="Oct" value="10">10-Oct</option>
                              <option data-text="Nov" value="11">11-Nov</option>
                              <option data-text="Dec" value="12">12-Dec</option>
                            </select>
                          </label>
                          <label><span class="screen-reader-text">Day</span>
                            <input type="text" autocomplete="off" maxlength="2" size="2" value="13" name="jj" id="jj">
                          </label>
                          ,
                          <label><span class="screen-reader-text">Year</span>
                            <input type="text" autocomplete="off" maxlength="4" size="4" value="2016" name="aa" id="aa">
                          </label>
                          @
                          <label><span class="screen-reader-text">Hour</span>
                            <input type="text" autocomplete="off" maxlength="2" size="2" value="07" name="hh" id="hh">
                          </label>
                          :
                          <label><span class="screen-reader-text">Minute</span>
                            <input type="text" autocomplete="off" maxlength="2" size="2" value="58" name="mn" id="mn">
                          </label>
                        </div>
                        <input type="hidden" value="58" name="ss" id="ss">
                        <input type="hidden" value="07" name="hidden_mm" id="hidden_mm">
                        <input type="hidden" value="07" name="cur_mm" id="cur_mm">
                        <input type="hidden" value="13" name="hidden_jj" id="hidden_jj">
                        <input type="hidden" value="13" name="cur_jj" id="cur_jj">
                        <input type="hidden" value="2016" name="hidden_aa" id="hidden_aa">
                        <input type="hidden" value="2016" name="cur_aa" id="cur_aa">
                        <input type="hidden" value="07" name="hidden_hh" id="hidden_hh">
                        <input type="hidden" value="07" name="cur_hh" id="cur_hh">
                        <input type="hidden" value="58" name="hidden_mn" id="hidden_mn">
                        <input type="hidden" value="58" name="cur_mn" id="cur_mn">
                        <p> <a class="save-timestamp hide-if-no-js button" href="#edit_timestamp">OK</a> <a class="cancel-timestamp hide-if-no-js button-cancel" href="#edit_timestamp">Cancel</a> </p>
                      </fieldset>
                    </div>
                  </div>
                  <div class="clear"></div>
                </div>
                <div id="major-publishing-actions">
                  <div id="delete-action"> <a href="http://plugin.dev/wp-admin/post.php?post=18&amp;action=trash&amp;_wpnonce=fa1ef31dd2" class="submitdelete deletion">Move to Trash</a></div>
                  <div id="publishing-action"> <span class="spinner"></span>
                    <input type="hidden" value="Publish" id="original_publish" name="original_publish">
                    <input type="submit" value="Publish" class="button button-primary button-large" id="publish" name="publish">
                  </div>
                  <div class="clear"></div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
