<?php
class OPE_Default_Analytics extends OPE_Abstract{
    public function index(){
         $this->render('index');
    }
}
?>