<?php
class OPE_Default_Setup extends OPE_Abstract{
    public function index(){
         $this->render('index');
    }
}
?>