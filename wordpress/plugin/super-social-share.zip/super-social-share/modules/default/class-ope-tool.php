<?php
class OPE_Default_Tool extends OPE_Abstract{
    public function index(){
         $this->render('index');
    }
}
?>