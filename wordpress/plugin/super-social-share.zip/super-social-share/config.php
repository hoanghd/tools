<?php
return array(
    'core' => array(
        array( 'add_action', 'admin_menu', 'fn(~.admin.menu)' ),
        array( 'add_action', 'admin_init', 'fn(~.admin.init)' ),
        array( 'add_action', 'admin_enqueue_scripts', 'fn(~.admin.scripts_default|0|/\_ope\-/)' ),
        array( 'add_action', 'admin_enqueue_scripts', 'fn(~.admin.elements_default|0|/\_ope\-/)' ),
        array( 'add_action', 'admin_enqueue_scripts', 'fn(~.admin.scripts_public)' ),
    ),
    'admin' => array(
        'init' => array(
            array('add_action', 'wp_(ajax|ajax_nopriv)_customizer_load', 'fn(Default_Customizer.load)' ),
            array('add_action', 'wp_(ajax|ajax_nopriv)_customizer_save', 'fn(Default_Customizer.save)' )
        ),
        'menu' => array(
            'setup'      => array( 'add_menu_page', esc_html__( 'Super Social Share', OPE_LANG ), esc_html__( 'Super Social Share', OPE_LANG ), 'manage_options', 'ope-super-social-share', 'fn(Default_Setup.index)', 'div' ),
            'customizer' => array( 'add_submenu_page', 'ope-super-social-share', esc_html__( 'Live Customize', OPE_LANG ), esc_html__( 'Live Customize', OPE_LANG ), 'manage_options', 'ope-customizer', 'fn(Default_Customizer.index)'),
            'setting'    => array( 'add_submenu_page', 'ope-super-social-share', esc_html__( 'General Settings', OPE_LANG ), esc_html__( 'General Settings', OPE_LANG ), 'manage_options','ope-general-settings', 'fn(Default_Setting.index)'),
            'tool'       => array( 'add_submenu_page', 'ope-super-social-share', esc_html__( 'Export/Import', OPE_LANG ), esc_html__( 'Export/Import', OPE_LANG ), 'manage_options','ope-export-import', 'fn(Default_Tool.index)'),
            'analytics'  => array( 'add_submenu_page', 'ope-super-social-share', esc_html__( 'Analytics', OPE_LANG ), esc_html__( 'Analytics', OPE_LANG ), 'manage_options','ope-analytics', 'fn(Default_Analytics.index)'),
            'customizer-view' => array( 'add_submenu_page', 'ope-customizer', 'Hidden!', 'Hidden!', 'manage_options', 'ope-customizer-view', 'fn(Default_Customizer.view)'),
            
            array( 'add_action', 'admin_print_scripts-{admin.menu.setup}', 'fn(~.admin.pages.setup_script)'),
            array( 'add_action', 'admin_print_scripts-{admin.menu.tool}',  'fn(~.admin.pages.tool_script)'),
            array( 'add_action', 'admin_print_scripts-{admin.menu.analytics}',  'fn(~.admin.pages.analytics_script)'),
            array( 'add_action', 'admin_print_scripts-{admin.menu.setting}',    'fn(~.admin.pages.settings_script)'),
            array( 'add_action', 'admin_print_scripts-{admin.menu.customizer}', 'fn(~.admin.pages.customizer_script)'),
            array( 'add_action', 'admin_print_scripts-{admin.menu.customizer-view}', 'fn(~.admin.pages.customizer_view_script)'),
            
            array( 'add_action', 'admin_menu', 'fn(Setting.admin_menu_rename)', 9999 ),
        ),
        'scripts_public' => array(
            
        ),
        'scripts_default' => array(
            array( 'wp_enqueue_script', '(jQuery|backbone|underscore)' ),
            array( 'wp_enqueue_{0}',  'jquery-ui-{0}',  plugins_url('/assets/libs/jquery-ui/jquery-ui.min.(css|js)',__FILE__) ),
            array( 'wp_enqueue_{0}', 'jquery-select2-{0}', plugins_url('/assets/libs/select2/dist/{0}/select2.full.min.(js|css)', __FILE__) ),
            array( 'wp_enqueue_script', 'jquery-slimscroll-script', plugins_url('/assets/libs/slimScroll/jquery.slimscroll.min.js', __FILE__), array(), false, true ),
            array( 'wp_enqueue_script', 'ope-modernizr-script', plugins_url('/assets/js/vendor/modernizr-2.8.3-respond-1.4.2.min.js', __FILE__) ),
            array( 'wp_enqueue_script', 'ope-form-validator-script', plugins_url('/assets/libs/jquery.form-validator/jquery.form-validator.min.js', __FILE__) ),
            array( 'wp_enqueue_style',  'ope-ionicons-style',  plugins_url('/assets/libs/ionicons/css/ionicons.min.css',__FILE__) ),
            array( 'wp_enqueue_style',  'ope-font-awesome-style',  plugins_url('/assets/libs/font-awesome/css/font-awesome.min.css',__FILE__) ),
            array( 'wp_enqueue_style',  'ope-normalize-style', plugins_url('/assets/css/normalize.min.css',__FILE__) ),
            array( 'wp_enqueue_script', 'ope-main-script', plugins_url('/assets/js/main.js', __FILE__), array(), false, true ),
            array( 'wp_enqueue_style',  'ope-{0}-style',  plugins_url('/assets/css/(core|main).css',__FILE__) ),
        ),
        'elements_default' => array(
            array( 'wp_enqueue_script', 'jquery.tmpl', plugins_url('/assets/libs/jquery.tmpl/jquery.tmpl.min.js', __FILE__), array(), false, true ),
            array( 'wp_enqueue_script', 'helpers.{0}', plugins_url('/assets/helpers/(overwrite).js', __FILE__), array(), false, true ),
            array( 'wp_enqueue_{0}',  'ope-element-{0}',  plugins_url('/assets/{0}/element.(css|js)',__FILE__)),
        ),
        'elements_scripts' => array(
            'media' => array(
                array('wp_enqueue_media')
            ),
            'colorpicker' => array(
                array( 'wp_enqueue_(style|script)',  'wp-color-picker' ),
            ),
            'datepicker' => array(
                array( 'wp_enqueue_script', 'jquery-ui-datepicker')
            ),
            'numeric_stepper' => array(
                array( 'wp_enqueue_{0}', 'jquery-numeric-stepper-{0}', plugins_url('/assets/libs/jquery-numeric-stepper/stepper/jquery.stepper.min.(css|js)', __FILE__) ),
            ),
            'switchbutton' => array(
                array( 'wp_enqueue_{0}', 'jquery-switchbutton-{0}', plugins_url('/assets/libs/jquery-switchbutton/jquery.switchbutton.min.(css|js)', __FILE__) ),
            ),
            'select2' => array()
        ),
        'pages' => array(
            'tool_script' => array( 
                array( 'wp_enqueue_script', 'ope-tool-script', plugins_url('/assets/js/tool.js', __FILE__), array(), false, true )
            ),
            'setup_script' => array( 
                array( 'wp_enqueue_script', 'ope-setup-script', plugins_url('/assets/js/setup.js', __FILE__), array(), false, true )
            ),
            'settings_script' => array( 
                array( 'wp_enqueue_script', 'ope-settings-script', plugins_url('/assets/js/settings.js', __FILE__), array(), false, true )
            ),
            'analytics_script' => array( 
                array( 'wp_enqueue_script', 'ope-analytics-script', plugins_url('/assets/js/analytics.js', __FILE__), array(), false, true )
            ),
            'customizer_script' => array( 
                array( 'wp_enqueue_style',  'ope-customizer-menu-style', plugins_url('/assets/customizer/menu/css/customizer.css',__FILE__) ),
                array( 'wp_enqueue_script', 'ope-customizer-menu-{0}-script', plugins_url('/assets/customizer/menu/js/(init|data|network|network-dialog|network-setting).js', __FILE__), array(), false, true  )
            ),
            'customizer_view_script' => array(
                array( 'wp_enqueue_style',  'ope-customizer-view-style', plugins_url('/assets/customizer/view/css/customizer.css',__FILE__) ),
                array( 'wp_enqueue_script', 'ope-customizer-view-{0}-script', plugins_url('/assets/customizer/view/js/(init|element).js', __FILE__), array(), false, true  )
            )
        )
    )
);