<?php
return array(
    'core' => array(
        array( 'add_action', 'admin_menu', 'fn(~.add_admin_menu)' ),
        array( 'add_action', 'admin_enqueue_scripts', 'fn(~.admin_scripts)', 100 ) //|0|/super-social-share/
    ),
    'add_admin_menu' => array(
        array( 'add_menu_page', esc_html__( 'Super Social Share', OPE_LANG ), esc_html__( 'Super Social Share', OPE_LANG ), 'access_cp', 'ope-super-social-share', 'fn(Default_Setup.index)', 'div' ),
        array( 'add_submenu_page', 'ope-super-social-share', esc_html__( 'Advanced Settings', OPE_LANG ), esc_html__( 'Advanced Settings', OPE_LANG ), 'access_cp','ope-advanced-settings', 'fn(Default_Setting.index)'),
        array( 'add_submenu_page', 'ope-super-social-share', esc_html__( 'Export/Import', OPE_LANG ), esc_html__( 'Export/Import', OPE_LANG ), 'access_cp','ope-export-import', 'fn(Default_Tool.index)'),
        array( 'add_submenu_page', 'ope-super-social-share', esc_html__( 'Analytics', OPE_LANG ), esc_html__( 'Analytics', OPE_LANG ), 'access_cp','ope-analytics', 'fn(Default_Analytics.index)'),
        
        array( 'add_action', 'admin_print_scripts-toplevel_page_ope-super-social-share', 'fn(~.add_page_setup_script)'),
        array( 'add_action', 'admin_print_scripts-super-social-share_page_ope-export-import', 'fn(~.add_page_tool_script)'),
        array( 'add_action', 'admin_print_scripts-super-social-share_page_ope-analytics', 'fn(~.add_page_analytics_script)'),
        array( 'add_action', 'admin_print_scripts-super-social-share_page_ope-advanced-settings', 'fn(~.add_page_settings_script)'),
        
        array( 'add_action', 'admin_menu', 'fn(Setting.admin_menu_rename)', 9999 ),
    ),
    'admin_scripts' => array(
        array( 'wp_enqueue_script', 'jQuery' ),
        array( 'wp_enqueue_script', 'ope-modernizr-script', plugins_url('/assets/js/vendor/modernizr-2.8.3-respond-1.4.2.min.js', __FILE__) ),
        array( 'wp_enqueue_script', 'ope-form-validator-script', plugins_url('/assets/js/jquery.form-validator.min.js', __FILE__) ),
        array( 'wp_enqueue_style', 'ope-ionicons-style', plugins_url('/assets/libs/ionicons/css/ionicons.min.css',__FILE__) ),
        array( 'wp_enqueue_style', 'ope-normalize-style', plugins_url('/assets/css/normalize.min.css',__FILE__) ),
        array( 'wp_enqueue_style', 'ope-core-style', plugins_url('/assets/css/core.css',__FILE__) ),
        array( 'wp_enqueue_style', 'ope-main-style', plugins_url('/assets/css/main.css',__FILE__) ),
    ),
    'add_page_tool_script' => array( array( 'wp_enqueue_script', 'ope-tool-script', plugins_url('/assets/js/tool.js', __FILE__) )  ),
    'add_page_setup_script' => array( array( 'wp_enqueue_script', 'ope-setup-script', plugins_url('/assets/js/setup.js', __FILE__) ) ),
    'add_page_settings_script' => array( array( 'wp_enqueue_script', 'ope-settings-script', plugins_url('/assets/js/settings.js', __FILE__) ) ),
    'add_page_analytics_script' => array( array( 'wp_enqueue_script', 'ope-analytics-script', plugins_url('/assets/js/analytics.js', __FILE__) ))
);