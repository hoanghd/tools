<?php

/*
* Plugin Name: Super Social Share
* Description: Super Social Share automatically adds share bar to your post or pages with support of Facebook, Twitter, Google+, LinkedIn, Pinterest, Digg, StumbleUpon, VKontakte, Tumblr, Reddit, Print, E-mail and other 30 social networks. Easy Social Share Buttons for WordPress is compatible with WooCommerce, bbPress and BuddyPress
* Plugin URI: http://themeforest.net/user/swlabs
* Version: 1.0
* Author: Swlabs
* Author URI: http://themeforest.net/user/swlabs
*/

clearstatcache();

defined( 'OPE_VERSION' )        || define( 'OPE_VERSION', '1.0' );
defined( 'OPE_LANG' )           || define( 'OPE_LANG', 'super-social-share' );
defined( 'OPE_URI' )            || define( 'OPE_URI', plugin_dir_url( __FILE__ ) );
defined( 'OPE_DIR' )            || define( 'OPE_DIR', dirname( __FILE__ ) );
defined( 'OPE_INC_DIR' )        || define( 'OPE_INC_DIR', OPE_DIR . '/includes' );
defined( 'OPE_MOD_DIR' )        || define( 'OPE_MOD_DIR', OPE_DIR . '/modules' );
defined( 'OPE_ASSET_URI' )      || define( 'OPE_ASSET_URI', OPE_URI . 'assets' );

include_once( ABSPATH . 'wp-admin/includes/plugin.php' );
require_once( plugin_dir_path( __FILE__ ) . '/includes/class-ope-manager.php' );

OPE_Manager::import('Abstract');
OPE_Manager::register('core');