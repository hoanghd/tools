<?php
return array(
    array('type'=>'facebook', 'name'=>'Facebook', 'num'=>10),
    array('type'=>'twitter', 'name'=>'Twitter', 'num'=>1),
    array('type'=>'pinterest', 'name'=>'Pinterest', 'num'=>5),
    array('type'=>'google-plus', 'name'=>'Google plus', 'num'=>5),
    array('type'=>'instagram', 'name'=>'Instagram', 'num'=>7),
);