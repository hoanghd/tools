jQuery(function($) {
    "use strict";

    var APP = window.APP || {};

    /**
     *  TEMPLATE DEMO FUNCTION
     */

    APP.templateDemoFunc = function() {

    	$('.ope-template-list-demo').on('select2:select', function (e) {

    		// Thêm class template vào khung preview
		  	var val_template = e.params.data.element.attributes[0].value;
		  	$('#preview > .ope-demo-content > ul').removeClass();
		  	$('#preview > .ope-demo-content > ul').addClass(val_template);

	  		// Nếu chọn có counter thì show counter option ra
	  		var counter_option = $('.ope-counter-option');
	  		if ( val_template.indexOf('ope-template-count') >= 0 ){
  				counter_option.addClass('has-counter');
	  		} else{
	  			counter_option.removeClass('has-counter');
	  		}
	  		// Nếu chọn có total counter thì show total counter option ra
	  		var total_counter_option = $('.ope-total-counter-option');
	  		if ( val_template.indexOf('ope-template-total-count') >= 0 ){
  				total_counter_option.addClass('has-total-counter');
	  		} else{
	  			total_counter_option.removeClass('has-total-counter');
	  		}

		});


    	// Counter option
		$('.ope-counter-option select').on('select2:select', function (e) {

    		// Thêm class template vào khung preview
		  	var val_counter_option = e.params.data.element.attributes[0].value;
		  	// $('#preview > .ope-demo-content > ul').removeClass();
		  	$('#preview > .ope-demo-content > ul').toggleClass(val_counter_option);

		});


    	// Total Counter option
		$('.ope-total-counter-option select').on('select2:select', function (e) {

    		// Thêm class template vào khung preview
		  	var val_total_counter_option = e.params.data.element.attributes[0].value;
		  	// $('#preview > .ope-demo-content > ul').removeClass();
		  	$('#preview > .ope-demo-content > ul').toggleClass(val_total_counter_option);

		});

    }




    /**
     *  INIT FUNCTIONS
     */

    $(document).ready(function() {
        APP.templateDemoFunc();
    });


});
