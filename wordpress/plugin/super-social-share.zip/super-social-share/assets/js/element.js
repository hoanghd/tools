jQuery(document).ready(function($){
    var ope_media_frame;
    
    $('.wp-ope-color-picker').each(function(index, elm){
        $(elm).wpColorPicker();
    });
    
    $('.wp-ope-stepper').each(function(index, elm){
        $(elm).stepper($(elm).data());
    });
    
    $('.wp-ope-date-picker').each(function(index, elm){
        $(elm).datepicker({
            'dateFormat' : ($(elm).attr('dateFormat') || 'yy-mm-dd')
        });
    });
    
    $(".wp-ope-select2").each(function(index, elm) {
        $(elm).select2($(elm).data());
    });
    
    $('.wp-ope-group-slider').each(function(index, elm) {
        var slider = $('.wp-ope-slider', elm);
        var stepper = $('.wp-ope-stepper', elm);
        
        var options = slider.data();
        options.slide = function( event, ui ) {
            stepper.val(ui.value);
        }
         
        slider.slider(options);
        stepper.data('stepper').onStep(function(val, up){
            slider.slider( "value",  val );
        });
        stepper.keypress(function(){
             slider.slider( "value",  $(this).val() );
        });
    });
    
    $('.wp-ope-media-group').each(function(index, elm) {
        var media_open = $('.open', elm);
        var media_image = $('.image', elm);
        var media_sizes = $('.sizes select', elm);
        var media_remove = $('.remove', elm);
        var media_hidden = $('input.hidden', elm);
        
        var fn_update = function(data){
            if(_.isEmpty(data)){
                media_image.html('<p class="description">No Image Selected</p>');
                media_sizes.parents('.sizes').hide();
                media_hidden.val('');
                media_remove.hide();
            }
            else {
                media_image.html($('<img/>').attr('src', data.image));
                media_sizes.parents('.sizes').show();
                media_remove.show();
                
                $("option", media_sizes).remove();
                media_sizes.append(
                   $('<option/>')
                );
                _.each(data.sizes, function(value, index){
                    media_sizes.append(
                         $('<option/>').val(index).text(value)
                    );
                });
                media_hidden.val('');
                
                if(data.attachment_size){
                    media_sizes.find("option[value='" + data.attachment_size + "']").attr('selected', true);
                }
                
                if( data.attachment_id ) {
                    media_hidden.val(JSON.stringify({ 'attachment_id' : data.attachment_id, 'attachment_size': (data.attachment_size || '') }));
                }
            }
        };
        
        fn_update(media_hidden.data());
        
        media_remove.click(function() {
            fn_update(false);
        });
        
        media_sizes.change(function(e) {
            var val = {};
            if(media_hidden.val()){
                try{
                    val = JSON.parse(media_hidden.val());
                }
                catch(err) {
                    console.log(err);
                }
            }
            
            val.attachment_size = $(this).val();
            media_hidden.val(JSON.stringify(val));
        });
        
        media_open.unbind().click(function(){
            if ( ope_media_frame ) {
                ope_media_frame.open();
                return;
            }
            
            ope_media_frame = wp.media.frames.meta_image_frame = wp.media({
                title: 'Select or Upload Image',
                button: { text:  'Choose Image' },
                library: { type: 'image' },
                multiple: false
            });
            
            ope_media_frame.on('select', function(){
                var attachment = ope_media_frame.state().get('selection').first().toJSON();
                if( attachment ){
                    var sizes = {};
                    if(attachment.sizes){
                        $.each(attachment.sizes, function(index, value){
                            sizes[index] = (index + ' ' + value.width + 'x' + value.height);
                        });
                    }
                    
                    fn_update({
                        'attachment_id': attachment.id,
                        'image': attachment.url,
                        'sizes': sizes
                    });
                }
            });
            
            ope_media_frame.open();
        });
    });
});