jQuery(function($) {
    "use strict";

    var APP = window.APP || {};


    /**
     *  GLOBAL FUNCTION
     */

    APP.globalFunc = function() {

    	// Advanced Setting - sidebar slimScroll
    	$('.ope-sidebar-wrap').slimscroll({
		  height: 'auto'
		});


		// Advanced Setting - sidebar collapsed
		$('.ope-sub-sidebar-action > li > a.ope-action-collapse').on('click', function(){
		   $('.ope-advanced-setting').toggleClass('has-collapse');
		});
        
    	// Advanced Setting - sidebar toogle heading
    	var item_heading = $('.ope-advanced-sidebar .ope-option-list > li > .ope-item-heading');
    	item_heading.on('click', function() {
    		if($(this).parent().hasClass('active')){
				$(this).parent().removeClass('active');
    		} else{
    			$('.ope-advanced-sidebar .ope-option-list > li').removeClass('active');
    			$(this).parent().toggleClass('active');
    		}
    	});

    	// Advanced Setting - sidebar drag & drog manage network
    	$( ".ope-manage-networks-list-demo" ).sortable({
		      revert: 100,
		      placeholder: "ope-state-highlight"
	    });

    	// Advanced Setting - sidebar select2
    	$('.ope-select2').select2({
		  minimumResultsForSearch: Infinity
		});
    	$('.ope-select2-search').select2();

    	// Advanced Setting - sidebar position tooltip
    	function formatState (state) {
		  if (!state.id) { return state.text; }
		  var $state = $(
		    '<span data-img="' + state.element + '">' + state.text + '</span>'
		  );
		  console.log(state);
		  return $state;
		};

		$(".ope-select2-tooltip").select2({
		  templateResult: formatState
		});

    	$( document ).tooltip({
	      items: "[data-img]",
	      content: function() {
	        var element = $( this );
	        if ( element.is( "[data-img]" ) ) {
	          return "<img class='img-responsive' src='" + element.attr('data-img') +"'>";
	        }
	      }
	    });

	    $('[data-toggle="tooltip"]').tooltip(); 

    	// Advanced Setting - sidebar toogle shape
    	var item_shape = $('.ope-advanced-sidebar .ope-shape-list-demo > li > .ope-item-shape');
    	item_shape.on('click', function() {
    		$('.ope-advanced-sidebar .ope-shape-list-demo > li').removeClass('active');
			$(this).parent().toggleClass('active');
    	});

    	// Advanced Setting - sidebar toogle style
    	var item_style = $('.ope-advanced-sidebar .ope-style-list-demo > li > .ope-item-style');
    	item_style.on('click', function() {
    		$('.ope-advanced-sidebar .ope-style-list-demo > li').removeClass('active');
			$(this).parent().toggleClass('active');
    	});

    	// Advanced Setting - sidebar toogle position
    	var item_pos = $('.ope-advanced-sidebar .ope-position-list-demo > li > .ope-item-pos');
    	item_pos.on('click', function() {
    		$('.ope-advanced-sidebar .ope-position-list-demo > li').removeClass('active');
			$(this).parent().toggleClass('active');
    	});

    	// Advanced Setting - sidebar slider network max design option
    	$( "#slider-network-max" ).slider({
    		range: "min",
	      	value: 5,
	      	min: 0,
	      	max: 40,
	      	step: 1,
	      	slide: function( event, ui ) {
	        	$("#input-network-max").val(ui.value);
	      	}
	    });

    	// Advanced Setting - sidebar slider padding design option
    	$( "#slider-padding" ).slider({
    		range: "min",
	      	value: 20,
	      	min: 0,
	      	max: 25,
	      	step: 1,
	      	slide: function( event, ui ) {
	        	$("#input-padding").val(ui.value);
	      	}
	    });

    	// Advanced Setting - sidebar slider Set Counter min design option
    	$( "#slider-counter-min" ).slider({
    		range: "min",
	      	value: 50,
	      	min: 0,
	      	max: 1000,
	      	step: 5,
	      	slide: function( event, ui ) {
	        	$("#input-counter-min").val(ui.value);
	      	}
	    });

    	// Advanced Setting - sidebar slider Set Total Counter min design option
    	$( "#slider-total-counter-min" ).slider({
    		range: "min",
	      	value: 200,
	      	min: 0,
	      	max: 1000,
	      	step: 5,
	      	slide: function( event, ui ) {
	        	$("#input-total-counter-min").val(ui.value);
	      	}
	    });

    	// Advanced Setting - sidebar slider fixed width design option
    	$( "#slider-fixed-width" ).slider({
    		range: "min",
	      	value: 200,
	      	min: 0,
	      	max: 500,
	      	step: 5,
	      	slide: function( event, ui ) {
	        	$("#input-fixed-width").val(ui.value);
	      	}
	    });

    	// Advanced Setting - sidebar slider columns design option
    	$( "#slider-columns" ).slider({
    		range: "min",
	      	value: 2,
	      	min: 0,
	      	max: 12,
	      	step: 1,
	      	slide: function( event, ui ) {
	        	$("#input-columns").val(ui.value);
	      	}
	    });


    };



    /**
     *  DIALOG MORE NETWORKS FUNCTION
     */

    APP.dialogMoreNetworksFunc = function() {

    	$( "#ope-dialog-more-network" ).dialog({
			autoOpen: false,
			modal: true,
			width: 600,
			draggable: false,
			dialogClass: 'ope-dialog-custom'
		});

		// Link to open the dialog
		$( ".ope-btn-more-networks" ).click(function( event ) {
			$( "#ope-dialog-more-network" ).dialog( "open" );
			event.preventDefault();
		});

    }



    /**
     *  DIALOG MANAGE NETWORKS FUNCTION
     */

    APP.dialogManageNetworksFunc = function() {

    	$( "#ope-dialog-manage-network" ).dialog({
			autoOpen: false,
			modal: true,
			width: 600,
			draggable: false,
			dialogClass: 'ope-dialog-custom'
		});

		// Link to open the dialog
		$( ".ope-btn-add-networks" ).click(function( event ) {
			$( "#ope-dialog-manage-network" ).dialog( "open" );
			event.preventDefault();
		});

		// Select network to Manage networks
		$( "#ope-dialog-manage-network .ope-link-list > .ope-social-link" ).click(function( event ) {
			$(this).toggleClass('selected');
		});

    }




    /**
     *  INIT FUNCTIONS
     */

    $(document).ready(function() {
        APP.globalFunc();
        APP.dialogMoreNetworksFunc();
        APP.dialogManageNetworksFunc();
    });


});
