jQuery(function($) {
    "use strict";

    var APP = window.APP || {};


    /**
     *  GLOBAL FUNCTION
     */

    APP.globalFunc = function() {

    	// Advanced Setting - sidebar slimScroll
    	$('.ope-sidebar-wrap').slimscroll({
		  height: 'auto'
		});


		// Advanced Setting - sidebar collapsed
		
        
    	// Advanced Setting - sidebar toogle heading
    	var item_heading = $('.ope-advanced-sidebar .ope-option-list > li > .ope-item-heading');
    	item_heading.on('click', function() {
    		if($(this).parent().hasClass('active')){
				$(this).parent().removeClass('active');
    		} else{
    			$('.ope-advanced-sidebar .ope-option-list > li').removeClass('active');
    			$(this).parent().toggleClass('active');
    		}
    	});

    	// Advanced Setting - sidebar toogle template

    	// Advanced Setting - sidebar drag & drog manage network
//    	$( ".ope-manage-networks-list-demo" ).sortable({
//		      revert: 100,
//		      placeholder: "ope-state-highlight"
//	    });

    	// Advanced Setting - sidebar select2 template
    	$('.ope-template-list-demo').select2({
    		placeholder: "Select a template network"
    	});

    	// Advanced Setting - sidebar toogle shape
    	var item_shape = $('.ope-advanced-sidebar .ope-shape-list-demo > li > .ope-item-shape');
    	item_shape.on('click', function() {
    		$('.ope-advanced-sidebar .ope-shape-list-demo > li').removeClass('active');
			$(this).parent().toggleClass('active');
    	});

    	// Advanced Setting - sidebar toogle style
    	var item_style = $('.ope-advanced-sidebar .ope-style-list-demo > li > .ope-item-style');
    	item_style.on('click', function() {
    		$('.ope-advanced-sidebar .ope-style-list-demo > li').removeClass('active');
			$(this).parent().toggleClass('active');
    	});

    	// Advanced Setting - sidebar toogle position
    	var item_pos = $('.ope-advanced-sidebar .ope-position-list-demo > li > .ope-item-pos');
    	item_pos.on('click', function() {
    		$('.ope-advanced-sidebar .ope-position-list-demo > li').removeClass('active');
			$(this).parent().toggleClass('active');
    	});

    	// Advanced Setting - sidebar slider padding design option
    	$( "#slider-padding" ).slider({
    		range: "min",
	      	value: 10,
	      	min: 0,
	      	max: 20,
	      	step: 1
	    });


    };



    /**
     *  DIALOG MANAGE NETWORKS FUNCTION
     */

    APP.dialogManageNetworksFunc = function() {

    	$( "#ope-dialog-manage-network" ).dialog({
			autoOpen: false,
			modal: true,
			width: 600,
			draggable: false,
			dialogClass: 'ope-dialog-custom'
		});

		// Link to open the dialog
		$( ".ope-btn-add-networks" ).click(function( event ) {
			$( "#ope-dialog-manage-network" ).dialog( "open" );
			event.preventDefault();
		});

		// Select network to Manage networks
		$( "#ope-dialog-manage-network .ope-link-list > .ope-social-link" ).click(function( event ) {
			$(this).toggleClass('selected');
		});

    }




    /**
     *  INIT FUNCTIONS
     */

    $(document).ready(function() {
        APP.globalFunc();
        APP.dialogManageNetworksFunc();
    });


});
