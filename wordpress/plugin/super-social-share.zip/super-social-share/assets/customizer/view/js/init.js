var Customizer = {
    Models: {},
    Collections: {},
    Views: {},
    Templates:{},
    Elements: {
        Preview: '#preview'
    },
    Data: {},
    Message: function(message){
        Customizer.Data.Preview.set(JSON.parse(message.data));
    }
};

jQuery("script[type='text/template'][name]").each(function(index, element){
    Customizer.Templates[ jQuery(this).attr('name') ] = _.template( jQuery(element).html() );
});
    
(function ($) {
    "use strict";
    Customizer.Models.Preview = Backbone.Model.extend({});
    
    Customizer.Views.Preview = Backbone.View.extend({
        template: Customizer.Templates.Preview,
        el: Customizer.Elements.Preview,
        events: {},
        initialize: function() {
            this.listenTo( this.model, 'change', this.render );
        },
        render: function(){
            this.$el.html( this.template( {'data': this.model.toJSON() } ));
        }
    });
    
    Customizer.Data.Preview = new Customizer.Models.Preview();
    (new Customizer.Views.Preview( { model : Customizer.Data.Preview } ));
}(window.jQuery));

if (window.addEventListener) {
    window.addEventListener("message", Customizer.Message, false);
} else {
    window.attachEvent("onmessage", Customizer.Message);
}