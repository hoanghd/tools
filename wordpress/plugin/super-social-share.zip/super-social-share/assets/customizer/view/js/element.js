(function($){
    
    _.fn({
        $ope: { 
            social: function(row){
                var compiled  = _.template('<li class="ope-social-link ope-social-<%=row.type%>">\
                    <a href="javascript:void(0);">\
                        <i class="ope-social-icon"></i>\
                        <div class="ope-social-label">\
                            <div class="ope-social-name"><%=row.name%></div>\
                            <div class="ope-social-count"><span><%=$ope.count(row.type)%></span></div>\
                        </div>\
                    </a>\
                </li>');
                return compiled({'row': row});
            },
            total: function(row, data, type){
                 var compiled  = _.template('<li class="ope-social-link ope-social-total-count">\
                    <a href="javascript:void(0);">\
                        <div class="ope-social-label">\
                            <div class="ope-social-name">Total share:</div>\
                            <div class="ope-social-count"><span><%=$ope.count(row.type)%></span></div>\
                        </div>\
                    </a>\
                </li>');
                
                if( _.has( data, 'type' ) && /total/.test( data.type ) && data.pos_total == type ) {
                    return compiled({'row': row});
                }
                return '';
            },
            count: function(type){
                var items = [10, 15, 150, 550, '1k', '20k', '100k'];
                return items[Math.floor(Math.random()*items.length)];
            },
            type: function(data){
                var cls = [];
                
                if( _.has( data, 'type' ) ) {
                    if( /icon/.test(data.type) ) {
                        cls.push( 'ope-template-icon' );
                    }
                    
                    if( /name/.test(data.type) ) {
                        cls.push( 'ope-template-name' );
                    }
                    
                    if( /count/.test(data.type) ) {
                        cls.push( 'ope-template-count' );
                        
                        if( _.has( data, 'pos_count' ) ) {
                            cls.push( 'ope-template-count-' + data.pos_count );
                        }
                    }
                    
                    if( /total/.test(data.type) ) {
                        cls.push( 'ope-template-total-count' );
                        
                        if( _.has( data, 'pos_total' ) ) {
                            cls.push( 'ope-template-total-count-' + data.pos_total );
                        }
                    }
                }
                
                return cls.join(' ');
            }
        }
    });
})(jQuery);