(function($){
    _.fn({
        $ope: { 
            social: function(row){
                var compiled  = _.template('<li class="ope-social-link ope-social-<%=row.type%>">\
                    <a href="javascript:void(0);">\
                        <i class="ope-social-icon"></i>\
                        <div class="ope-social-label">\
                            <div class="ope-social-name"><%=row.name%></div>\
                            <div class="ope-social-count"><span><%=(row.num || 10)%></span></div>\
                        </div>\
                    </a>\
                </li>');
                return compiled({'row': row});
            }
        }
    });
})(jQuery);