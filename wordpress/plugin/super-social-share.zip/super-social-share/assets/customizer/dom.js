var Customizer = {
    Models: {},
    Collections: {},
    Views: {},
    Templates:{},
    Elements: {
        movie: '#container'
    }
};

jQuery("script[type='text/template'][name]").each(function(index, element){
    Customizer.Templates[jQuery(this).attr('name')] = _.template(jQuery(element).html());
});

Customizer.Views.Movie = Backbone.View.extend({
    el: Customizer.Elements.movie,
    template: Customizer.Templates.movie,
    
    events: {
      "click .rating" : "rating"
    },
    
    initialize: function () {
        _.bindAll(this, 'render');
        this.listenTo(this.model, 'change', this.render);
        this.render();
    },
    
    render: function () {
        return this.$el.html(this.template(this.model.toJSON()));
    },
    
    rating: function() {
          this.model.set({'rating': (this.model.get('rating') + 5)});
    },
})

Customizer.Models.Movie = Backbone.Model.extend({});

Customizer.movie = new Customizer.Models.Movie({title:'hello', style: '', rating: 50});
(new Customizer.Views.Movie( { model:  Customizer.movie}));

//Customizer.movie.set({title: 'ok baby', rating:1000});

//http://stackoverflow.com/questions/27266901/display-javascript-object-in-html
//http://www.tutorialspoint.com/backbonejs
//http://backbonejs.org/docs/todos.html
//http://adrianmejia.com/blog/2012/09/13/backbone-js-for-absolute-beginners-getting-started-part-2/
//http://code.tutsplus.com/articles/using-backbone-within-the-wordpress-admin-the-front-end--wp-30121
//http://www.bardev.com/2012/01/16/understanding-backbone-js-simple-example/
//http://stackoverflow.com/questions/16591359/backbone-js-update-view-on-model-change