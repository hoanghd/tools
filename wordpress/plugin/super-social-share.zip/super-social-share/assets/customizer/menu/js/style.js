(function ($) {
    "use strict";
    Customizer.Models.Style = Backbone.Model.extend({
        defaults: function() {
          return {
             style: '',
             shape: '',
             size: '',
             button_width: '',
             fixed_width: 0,
             columns: 0,
             animation: '',
             padding: 0
          };
        }
    });
    
    Customizer.Views.Style = Backbone.fn.View.extend({
        fields: Customizer.Data.Options.StyleFields,
        el: Customizer.Elements.Style,
        events: {},
        
        initialize: function() {
            this.listenTo( Customizer.Data.Style, 'change', this.render );
            this.render();
        },
        
        render: function(){
            this.postMessage();
        },
        
        postMessage: function(){
            Customizer.Preview.send({'Style': Customizer.Data.Style.toJSON()});
        }
    });
   
   Customizer.Data.Style = new Customizer.Models.Style();
   (new Customizer.Views.Style({model: Customizer.Data.Style}));
}(window.jQuery));