var Customizer = {
    Models: {},
    Collections: {},
    Views: {},
    Templates:{},
    Elements: {
        Menu: '.ope-customizer-menu',
        Style: '.ope-customizer-style',
        Network: '.ope-customizer-network',
        Template: '.ope-customizer-template',
        Social: '.ope-customizer-network-dialog'
    },
    Data: {
        Menu: {},
        Style: {},
        Network: {},
        NetworkSetting: {},
        Template: {},
        Social: []
    },
    Preview: {
        send: function(data){
            var iframe = jQuery('.ope-screen-live-preview-wrap iframe');
            if( iframe.length>0 ) {
                iframe.get(0).contentWindow.postMessage(JSON.stringify(data), iframe.attr('src'));
            }
        },
        load: function(){
            this.send({
                'Style': Customizer.Data.Style.toJSON(),
                'Network': Customizer.Data.Network.toJSON(),
                'Template': Customizer.Data.Template.toJSON(),
                'NetworkSetting': Customizer.Data.NetworkSetting.toJSON()
            });
        }
    }
};

jQuery("script[type='text/template'][name]").each(function(index, element){
    Customizer.Templates[ jQuery(this).attr('name') ] = _.template( jQuery(element).html() );
});
    
(function ($) {
    "use strict";
    Customizer.Models.Menu = Backbone.Model.extend({
        url: ajaxurl,
        defaults: {},
        parse: function( response, options ){
            _.each( response, function( value, index ){
                if( _.has( Customizer.Data, index ) ){
                    Customizer.Data[ index ].set( value );
                }
            })
        }
    });
    
    Customizer.Views.Menu = Backbone.View.extend({
        template: Customizer.Templates.Menu,
        el: Customizer.Elements.Menu,
        events: {},
        
        initialize: function() {
            Customizer.Data.Menu.fetch({
                data: {action: 'customizer_load'}
            });
        }
    });
    
    Customizer.Data.Menu = new Customizer.Models.Menu();
    (new Customizer.Views.Menu());
}(window.jQuery));