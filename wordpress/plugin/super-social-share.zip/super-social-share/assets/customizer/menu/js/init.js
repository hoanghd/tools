var Customizer = {
    Models: {},
    Collections: {},
    Views: {},
    Templates:{},
    Elements: {
        Menu: '.customizer-menu',
        Network: '.customizer-network',
        Social: '.customizer-network-dialog'
    },
    Data: {
        Menu: {},
        Network: {},
        Template: {},
        Social: []
    },
    Preview: {
        send: function(data){
            var iframe = jQuery('.ope-screen-live-preview-wrap iframe');
            if( iframe.length>0 ) {
                iframe.get(0).contentWindow.postMessage(JSON.stringify(data), iframe.attr('src'));
            }
        },
        load: function(){
            this.send({'Network': Customizer.Data.Network.toJSON()});
        }
    }
};

jQuery("script[type='text/template'][name]").each(function(index, element){
    Customizer.Templates[ jQuery(this).attr('name') ] = _.template( jQuery(element).html() );
});
    
(function ($) {
    "use strict";
    Customizer.Models.Menu = Backbone.Model.extend({
        url: ajaxurl,
        defaults: {},
        parse: function( response, options ){
            _.each( response, function( value, index ){
                if( _.has( Customizer.Data, index ) ){
                    Customizer.Data[ index ].set( value );
                }
            })
        }
    });
    
    Customizer.Views.Menu = Backbone.View.extend({
        template: Customizer.Templates.Menu,
        el: Customizer.Elements.Menu,
        events: {
          'click .ion-arrow-resize': 'resize',
          'click .ion-monitor': 'monitor',
          'click .ion-plus-round' : 'add',
          'click .ion-archive': 'archive',
          'click .ion-close-round': 'close'
        },
        initialize: function() {
            Customizer.Data.Menu.fetch({
                data: {action: 'customizer_load'}
            });
        },
        resize: function(){console.log('resize');},
        monitor: function(){console.log('monitor');},
        add: function(){console.log('add');},
        archive: function(){console.log('archive');},
        close: function(){console.log('close');}
    });
    
    Customizer.Data.Menu = new Customizer.Models.Menu();
    (new Customizer.Views.Menu());
}(window.jQuery));