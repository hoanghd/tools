(function ($) {
    "use strict";
    
    Customizer.Models.Social = Backbone.Model.extend({
        defaults: function() {
          return {
             type: '',
             name: '',
             num : 0
          };
        }
    });
    
    Customizer.Collections.Social = Backbone.Collection.extend({
         model: Customizer.Models.Social
    });
    
    Customizer.Views.Social = Backbone.View.extend({
        template: Customizer.Templates.Social,
        tagName:  'li',
        events: {
            'click'    : 'toggle',
        },
        
        initialize: function() {
            this.listenTo(this.model, 'change', this.render);
        },
        
        render: function() {
            this.$el.html( this.template({'row': this.model.toJSON() }));
            this.$el.addClass('ope-social-link ope-social-' + this.model.get('type') );
            
            if( Customizer.Data.Network.where({type: this.model.get('type')}).length>0 ) {
                this.$el.addClass('selected');
            }
            
            return this;
        },
        
        toggle: function(){
            var model = Customizer.Data.Network.where({type: this.model.get('type')});
            if(model.length > 0){
                _.each(model, function(row){
                    row.destroy();
                });
            } else {
                Customizer.Data.Network.push({type: this.model.get('type'), name:this.model.get('name')})
            }
        }
    });
    
    Customizer.Views.SocialList = Backbone.View.extend({
        el: Customizer.Elements.Social,
        events: {},
        
        initialize: function() {
            this.listenTo( Customizer.Data.Social, 'all', this.render );
            this.listenTo( Customizer.Data.Network, 'all', this.render );
            this.listenTo( Customizer.Data.Network, 'all', this.postMessage );
        },
        
        add: function(row) {
            var view = new Customizer.Views.Social({ model: row });
            this.$el.find('.ope-networks-dialog').append(view.render().el);
        },
        
        render: function() {
            this.$el.find(".ope-networks-dialog > li").remove();
            Customizer.Data.Social.each(this.add, this);
        },
        
        postMessage: function(){
            Customizer.Preview.send({'Network': Customizer.Data.Network.toJSON()});
        }
    });
   
   Customizer.Data.Social = new Customizer.Collections.Social();
   (new Customizer.Views.SocialList());
}(window.jQuery));