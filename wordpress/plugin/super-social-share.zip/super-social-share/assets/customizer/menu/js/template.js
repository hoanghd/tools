(function ($) {
    "use strict";
    Customizer.Models.Template = Backbone.Model.extend({
        defaults: function() {
          return {
             type : 'item-name-count',
             min_total_count: 0,
             pos_count: 'left',
             min_count: 0,
             pos_total: 'left',
             min_total: 0,
             mode: 'cache'
          };
        }
    });
    
    Customizer.Views.Template = Backbone.fn.View.extend({
        fields: Customizer.Data.Options.TemplateFields,
        el: Customizer.Elements.Template,
        events: {},
        
        initialize: function() {
            this.listenTo( Customizer.Data.Template, 'change', this.render );
            this.render();
        },
        
        render: function(){
            this.postMessage();
        },
        
        postMessage: function(){
            Customizer.Preview.send({'Template': Customizer.Data.Template.toJSON()});
        }
    });
   
   Customizer.Data.Template = new Customizer.Models.Template();
   (new Customizer.Views.Template({model: Customizer.Data.Template}));
}(window.jQuery));