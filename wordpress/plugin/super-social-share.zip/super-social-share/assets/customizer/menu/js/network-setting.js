(function ($) {
    "use strict";
    Customizer.Models.NetworkSetting = Backbone.Model.extend({
        defaults: function() {
          return {
             max_display : 0,
             button: '',
             icon: '',
             cnt: 0
          };
        },
        setCount: function( cnt ){
            if( cnt == -1 ) {
                cnt = Customizer.Data.Network.length;
            }
            
            if( cnt != this.get('cnt') ) {
                this.set({
                    'cnt': cnt, 
                    'max_display': Math.min( this.get( 'max_display' ), cnt ) 
                });
            }
        }
    });
    
    Customizer.Views.NetworkSetting = Backbone.fn.View.extend({
        fields: Customizer.Data.Options.NetworkSettingFields,
        el: Customizer.Elements.Network,
        events: {},
        
        initialize: function() {
            this.listenTo( Customizer.Data.NetworkSetting, 'change', this.render );
            this.render();
        },
        
        slideStop: function(event, ui) {
            if(ui.value && Customizer.Data.NetworkSetting.get('max_display') != ui.value ){
                Customizer.Data.NetworkSetting.set({'max_display': ui.value});
            }
        },
        
        render: function(){
            this.postMessage();
        },
        
        postMessage: function(){
            Customizer.Preview.send({'NetworkSetting': Customizer.Data.NetworkSetting.toJSON()});
        }
    });
   
   Customizer.Data.NetworkSetting = new Customizer.Models.NetworkSetting();
   (new Customizer.Views.NetworkSetting({model: Customizer.Data.NetworkSetting}));
}(window.jQuery));