(function ($) {
    "use strict";
    
    Customizer.Models.Network = Backbone.Model.extend({
        defaults: function() {
          return {
             type: '',
             name: ''
          };
        }
    });
    
    Customizer.Collections.Network = Backbone.Collection.extend({
         model: Customizer.Models.Network,
         moveTo: function(from, to){
            var model = this.at(from);
            if(from != to && model && (to < this.models.length)){
                var copy = model.clone();
                this.remove(model, {silent: true});
                this.add(copy, {at: to});
            }
        }
    });
    
    Customizer.Views.Network = Backbone.View.extend({
        template: Customizer.Templates.Network,
        tagName:  'li',
        events: {
            'blur .ope-input-name'      : 'close',
            'click .ope-btn-destroy'    : 'destroy',
            'keypress .ope-input-name'  : 'updateOnEnter'
        },
        
        initialize: function() {
            this.listenTo(this.model, 'change', this.render);
            this.listenTo(this.model, 'destroy', this.remove);
        },
        
        render: function() {
            this.$el.html( this.template( {'row': this.model.toJSON()} ) );
            this.$el.addClass('ope-social-link ope-social-' + this.model.get('type') );
            this.input = this.$el.find('.ope-input-name');
            return this;
        },
        
        updateOnEnter: function(e) {
          if (e.keyCode == 13) this.close();
        },
        close: function() {
            var value = this.input.val();
            this.model.set({'name': value});
        },
        
        destroy: function(){
            this.model.destroy();
            Customizer.Data.NetworkSetting.setCount( -1 );
        }
    });
    
    Customizer.Views.NetworkList = Backbone.View.extend({
        el: Customizer.Elements.Network,
        events: {},
        
        initialize: function() {
            this.listenTo( Customizer.Data.Network, 'all', this.addAll );
            this.$(".ope-networks-list").sortable({
                revert: 100,
                placeholder: 'ope-state-highlight',
                start: _.bind(function(event, ui) {
                    ui.item.data('start_pos', ui.item.index());
                }, this),
                update: _.bind(function(event, ui) {
                    Customizer.Data.Network.moveTo(ui.item.data('start_pos'), ui.item.index());
                }, this)
            });
        },
        
        addOne: function(row) {
            var view = new Customizer.Views.Network({ model: row });
            this.$el.find(".ope-networks-list").append(view.render().el);
        },
        
        addAll: function() {
            this.$el.find(".ope-networks-list > li").remove();
            Customizer.Data.Network.each(this.addOne, this);
        }
    });
    
    Customizer.Data.Network = new Customizer.Collections.Network();
    (new Customizer.Views.NetworkList());
}(window.jQuery));