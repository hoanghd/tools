Customizer.Data.Options = {
    NetworkSettingFields: {
        button: {
            data: {'button': 'Display network after more button', 'popup': 'Display network as popup'},
            htmlOptions: {
                select2: {minimumResultsForSearch: Infinity},
                class: 'form-control', 
                empty: ''
            }
        },
        icon: {
            data: {'plus': 'Plus icon', 'dot': 'Dot icon'},
            htmlOptions: {
                select2: {minimumResultsForSearch: Infinity},
                class: 'form-control ope-input-small', 
                empty: ''
            }
        }
    }
};