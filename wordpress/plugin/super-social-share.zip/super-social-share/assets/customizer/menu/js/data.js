Customizer.Data.Options = {
    NetworkSettingFields: {
        button: {
            data: {'button': 'Display network after more button', 'popup': 'Display network as popup'},
            htmlOptions: {
                select2: {'minimumResultsForSearch': 'Infinity'},
                class: 'form-control', 
                empty: ''
            }
        },
        icon: {
            data: {'plus': 'Plus icon', 'dot': 'Dot icon'},
            htmlOptions: {
                select2: {'minimumResultsForSearch': 'Infinity'},
                class: 'form-control ope-input-small', 
                empty: ''
            }
        },
        max_display: {
            htmlOptions: {
                'min' : 0, 
                'max' : 'fn:[this.model|cnt]'
            }
        }
    },
    TemplateFields: {
        type: {
            data: {
                'icon-name': 'Icon - Name',
                'name-count': 'Name - Counter',
                'icon-name-count': 'Icon - Name - Counter',
                'icon-name-total': 'Icon - Name - Total Counter',
                'icon-count' : 'Icon - Counter',
                'icon': 'Icon'
            },
            htmlOptions: {
                class: 'ope-template-list-demo form-control',
                'data-placeholder': 'Select a template network'
            }
        },
        pos_count: {
            data: {'top': 'Top', 'left': 'Left', 'right': 'Right', 'bottom': 'Bottom'},
            htmlOptions: {
                class: 'form-control ope-input-small',
                select2: {'minimumResultsForSearch': 'Infinity'}
            }
        },
        min_count: {
            htmlOptions: {
                'min': 0, 
                'max': 1000, 
                'step': 50, 
                'range': 'min'
            }
        },
        pos_total: {
            data: {'top': 'Top', 'left': 'Left', 'right': 'Right', 'bottom': 'Bottom'},
            htmlOptions: {
                class: 'form-control ope-input-small',
                select2: {'minimumResultsForSearch': 'Infinity'}
            }
        },
        min_total: {
            htmlOptions: {
                'min': 0, 
                'max': 1000, 
                'step': 50, 
                'range': 'min'
            }
        },
        mode: {
            data: {'cache': 'Cache share', 'real': 'Real time share'},
            htmlOptions: {
                class: 'form-control ope-input-medium',
                select2: {'minimumResultsForSearch': 'Infinity'}
            }
        }
    }
};