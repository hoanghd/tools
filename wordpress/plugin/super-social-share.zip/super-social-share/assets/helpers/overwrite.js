(function() {
    var _original_template = _.template;
    var _template_helpers = {};
    _.mixin( {
        fn : function( newHelpers ) {
            _.extend( _template_helpers, newHelpers );
        },
        template : function( text, data, settings ) {
            if( data ) {
                _.defaults( data, _template_helpers );
                return _original_template.apply( this, arguments );
            }
            
            var template = _original_template.apply( this, arguments );
            var wrappedTemplate = function( data ) {
                data = _.defaults( {}, data, _template_helpers );
                return template.call( this, data );
            };
            return wrappedTemplate;
        }
    } );
} )();

(function ($) {
    "use strict";
    Backbone.fn = {
        View: Backbone.View.extend({
            _callback: [],
            
            events: {
                'change [fn] input': '_field_changed',
                'change [fn] select': '_selection_changed'
            },
            
            _before_render: function(){
                this.$el.find( '[fn]' ).each(function( index, el ){
                    if( _.isFunction( $('select', el).select2 ) ) {
                        $('select', el).select2( 'destroy' );
                    }
                    else if( _.isFunction( $(el).slider ) ) {
                        $(el).slider( 'destroy' );
                    }
                });
            },
            
            _replace: function( has ){
                var mt = {};
                var self = this;
                
                _.each( has, function( value, key ){
                    if( _.isString( value ) && ( mt = value.match( /^fn\:\[([^\]]+)\]$/ ) ) ) {
                        has[ key ] = self._get( mt[1] );
                    }
                });
                
                return has;
            },
            
            _get: function(_key){
                var _keys = _key.split( '.' );
                var _current = window;
                
                if( _keys[0] == 'this' ) {
                    _current = this;
                    _keys.shift();
                }
                
                for(var i=0, len=_keys.length; i<len; i++){
                    var _field = _keys[ i ];
                    var _mt = [];
                    if( _mt = _field.match( /^([^\|]+)\|(.*)$/ ) ) {
                        _field = _mt[ 1 ];
                    }
                    
                    if('undefined' == typeof( _current[ _field ] ) ){
                        return undefined;
                    }
                    else{
                        if( _mt && _mt.length>0 ) {
                            _current = _current[ _field ].get( _mt[ 2 ] );
                        } else {
                            _current = _current[ _field ];
                        }
                    }
                }
                
                return _current;
            },
            
            _after_render: function(){
                var self = this;
                if( this.$el.length > 0 ) {
                    var fields = ( self.fields || {} );
                    
                    this.$el.find( '[fn]' ).each(function( index, el ){
                        var $el     = $( el );
                        var attr    = $el.data();
                        var fnName  = $el.attr( 'fn' );
                        
                        if( _.has( fields, attr.name ) ) {
                            var data = fields[ attr.name ];
                            
                            if( _.has( data, 'htmlOptions' ) ) {
                                attr.htmlOptions = $.extend( true, {}, data.htmlOptions, ( attr.htmlOptions || {} ) );
                            }
                            
                            attr  = $.extend( true, {}, { label: '', name: '', value: '', htmlOptions: {}, data: {} }, _.omit( data, 'htmlOptions' ), attr );
                        }
                        
                        var htmlOptions = self._replace( attr.htmlOptions );
                        
                        if( attr.model && _.has( self, attr.model ) && _.isFunction( self[ attr.model ].get ) ) {
                            attr[ 'value' ] = self[ attr.model ].get( attr.name );
                        }
                        
                        if( _.has( Backbone.fn.Element, fnName ) ) {
                            $el.html(
                                _.bind( Backbone.fn.Element[ fnName ], Backbone.fn.Element, attr.name, attr.value, htmlOptions, attr.data, self, $el )
                            );
                        }
                    });
                    
                    this.$el.find( '[fn-if]' ).each(function( index, el ){
                        var $el = $( el );
                        var compiled  = _.template( $el.attr( 'fn-if' ) );
                        
                        if( parseInt( compiled( self ) ) == 1) {
                            $el.show();
                        } else {
                            $el.hide();
                        }
                    });
                    
                    if( this._callback.length> 0 ) {
                        _.each( this._callback, function( fn ){
                            fn.call( self );
                        });
                    }
                }
            },
            
            _field_changed: function( e ){
                var field = $( e.currentTarget );
                var data = {};
                data[ field.attr( 'id' ) ] = field.val();
                this.model.set( data );
            },
            
            _selection_changed: function( e ){
                var field = $( e.currentTarget );
                var value = $( 'option:selected', field ).val();
                var data = {};
                data[ field.attr( 'id' ) ] = value;
                this.model.set( data );
            }
        }),
        
        Element: {
            slider: function(name, value, $htmlOptions, data, view, $el){
                var htmlOptions = _.clone( $htmlOptions );
                htmlOptions.value = value;
                
                var options = _.pick(htmlOptions, 'disabled', 'max', 'min', 'orientation', 'range', 'step', 'value', 'values');
                var events =  _.pick(htmlOptions, 'change', 'create', 'slide', 'start', 'stop');
                 
                view._callback.push(function(){
                    _.each(events, function(callback, evt){
                        if( _.isFunction( view[ callback ] ) ) {
                            options[ evt ] = view[ callback ];
                        }
                    });
                    
                    $el.slider(options);
                });
                
                return this.tag('span');
            },
            
            select2: function(name, value, $htmlOptions, data, view, $el){
                var htmlOptions = _.clone( $htmlOptions );
                var select2 = htmlOptions['select2']  || {};
                delete htmlOptions['select2'];
                
                var content = this.dropDownList(name, value, htmlOptions, data);
                
                view._callback.push(function(){
                    $el.find('select').select2(select2);
                });
                
                return content;
            },
            
            textfield: function( name, value, htmlOptions ){
                return this.inputField( 'text', name, value, htmlOptions );
            },
            numberField: function( name, value, htmlOptions ) {
                return this.inputField( 'number', name, value, htmlOptions );
            },
            
            rangeField: function( name, value, htmlOptions ) {
                return this.inputField( 'range', name, value, htmlOptions );
            },
            
            dateField: function( name, value, htmlOptions ) {
                return this.inputField( 'date', name, value, htmlOptions );
            },
            
            timeField: function( name, value, htmlOptions ) {
                return this.inputField( 'time', name, value, htmlOptions );
            },
            
            dateTimeField: function( name, value, htmlOptions ) {
                return this.inputField( 'datetime', name, value, htmlOptions );
            },
            
            dateTimeLocalField: function( name, value, htmlOptions ) {
                return this.inputField( 'datetime-local', name, value, htmlOptions );
            },
            
            weekField: function( name, value, htmlOptions ) {
                return this.inputField( 'week', name, value, htmlOptions );
            },
            
            emailField: function( name, value, htmlOptions) {
                return this.inputField( 'email', name, value, htmlOptions );
            },
            
            telField: function( name, value, htmlOptions ) {
                return this.inputField( 'tel', name, value, htmlOptions );
            },
            
            urlField: function( name, value, htmlOptions ) {
                return this.inputField( 'url', name, value, htmlOptions );
            },
            
            hiddenField: function( name, value, htmlOptions ) {
                return this.inputField( 'hidden', name, value, htmlOptions );
            },
            
            passwordField: function( name, value, htmlOptions ) {
                return this.inputField( 'password', name, value, htmlOptions );
            },
            
            fileField: function( name, value, htmlOptions ) {
                return this.inputField( 'file', name, value, htmlOptions );
            },
            
            textArea: function( name, value, $htmlOptions ) {
                var htmlOptions = $.extend( true, {}, ( $htmlOptions || {} ) , { 'name': name });
                
                if( !_.has(htmlOptions, 'id') ) {
                    htmlOptions['id'] = this.toIdByName( name );
                }
                    
                return this.tag( 'textarea', htmlOptions, value );
            },
            
            radioButton: function( name, checked, $htmlOptions ) {
                var htmlOptions = _.clone( $htmlOptions );
                htmlOptions = (htmlOptions || {});
                
                if(checked)
                    htmlOptions['checked']='checked';
                else
                    delete htmlOptions['checked'];
                    
                var value   = (htmlOptions['value'] || 1);
                var uncheck = null;
                var hidden  = '';
                
                if( _.has(htmlOptions, 'uncheckValue') ) {
                    uncheck = htmlOptions['uncheckValue'];
                    delete htmlOptions['uncheckValue'];
                }
                
                if( uncheck !== null ) {
                    hidden = this.hiddenField( name, uncheck );
                }
                
                return hidden + this.inputField( 'radio', name, value, htmlOptions );
            },
            
            checkBox: function( name, checked, $htmlOptions ) {
                var htmlOptions = _.clone( $htmlOptions );
                htmlOptions = (htmlOptions || {});
                
                if( checked )
                    htmlOptions['checked']='checked';
                else
                    delete htmlOptions['checked'];
                    
                var value   = ( htmlOptions['value'] || 1 );
                var uncheck = null;
                var hidden  = '';
                
                if( _.has( htmlOptions, 'uncheckValue' ) ) {
                    uncheck = htmlOptions['uncheckValue'];
                    delete htmlOptions['uncheckValue'];
                }
                    
                
                if( uncheck !== null ) {
                    hidden = this.hiddenField( name, uncheck );
                }
                
                return hidden + this.inputField( 'checkbox', name, value, htmlOptions );
            },
            
            dropDownList: function( name, value, $htmlOptions, data ) {
                var htmlOptions = $.extend( true, {}, ( $htmlOptions || {} ) , { 'name': name });
                
                if( !_.has(htmlOptions, 'id') ) {
                    htmlOptions['id'] = this.toIdByName( name );
                }
                    
                var options = "\n" + this.listOptions( value, data, htmlOptions );
                var hidden = '';
                
                if( htmlOptions['multiple'] ) {
                    if( htmlOptions['name'].substr(-2) !== '[]' ) {
                        htmlOptions['name'] += '[]';
                    }
                    
                    if( _.has(htmlOptions, 'unselectValue')) {
                        hidden = this.hiddenField( htmlOptions['name'].substr( 0, htmlOptions['name'].length - 2 ), htmlOptions['unselectValue'] );
                        delete htmlOptions['unselectValue'];
                    }
                }
                
                return hidden + this.tag( 'select', htmlOptions, options );
            },
            
            listBox: function( name, value, data, $htmlOptions ) {
                var htmlOptions = _.clone( $htmlOptions );
                if( !_.has(htmlOptions, 'size') ) {
                    htmlOptions['size'] = 4;
                }
                
                if( htmlOptions['multiple'] ) {
                    if( name.substr(-2) !== '[]' ) {
                        name += '[]';
                    }
                }
                
                return this.dropDownList( name, value, htmlOptions, data );
            },
            
            checkBoxList: function( name, value, $htmlOptions, data ) {
                var self = this;
                var htmlOptions = _.clone( $htmlOptions );
                var template = ( htmlOptions['template'] || '{input} {label}' );
                var separator = ( htmlOptions['separator'] || this.tag('br') );
                
                delete htmlOptions['template'];
                delete htmlOptions['separator'];
               
                if( name.substr(-2) !=='[]' ) {
                    name += '[]';
                }
                
                var labelOptions = (htmlOptions['labelOptions'] || {});
                delete htmlOptions['labelOptions'];
                
                var baseID = ( htmlOptions['baseID'] || this.toIdByName( name ) );
                delete htmlOptions[ 'baseID' ];
                
                var checkAll = true;
                var items = [];
                var id = 0;
                
                _.each(data, function(labelTitle, val){
                    var checked = ( ( !_.isArray(value) && value == val ) || ( _.isArray(value) && self.inArray(value, val) ) );
                    var checkAll = (checkAll && checked);
                    
                    htmlOptions['value'] = val;
                    htmlOptions['id']    = baseID + '_' + (id++);
                    var option           = self.checkBox( name, checked, htmlOptions );
                    var beginLabel       = self.openTag( 'label', labelOptions );
                    var label            = self.label( labelTitle, htmlOptions['id'], labelOptions );
                    var endLabel         = self.closeTag( 'label' );
                    
                    items.push(template.replaceArray(
                        ['{input}', '{beginLabel}', '{label}', '{labelTitle}', '{endLabel}'],
                        [option, beginLabel, label,  labelTitle, endLabel]
                    ));
                });
                
                return items.join(separator);
            },
            
            
            radioButtonList: function( name, value, $htmlOptions, data ) {
                var self = this;
                var htmlOptions = _.clone( $htmlOptions );
                var template  = htmlOptions['template']  || '{input} {label}';
                var separator = htmlOptions['separator'] || this.tag('br');
                
                delete htmlOptions['template'];
                delete htmlOptions['separator'];
                
                var labelOptions = htmlOptions['labelOptions'] || {};
                delete htmlOptions['labelOptions'];
                
                if( htmlOptions['empty'] ) {
                    if( !_.isString(htmlOptions['empty']) )
                        htmlOptions['empty'] = { '' : htmlOptions['empty'] };
                    
                    data = $.extend( true, {}, htmlOptions['empty'], data );
                    delete htmlOptions['empty'];
                }
                
                var id = 0;
                var items = [];
                var baseID = htmlOptions['baseID'] || this.toIdByName(name);
                delete htmlOptions['baseID'];
                
                _.each(data, function(labelTitle, val){
                    htmlOptions['value']     = value;
                    htmlOptions['id']        = baseID + '_' + (id++);
                    
                    var checked    = (value == val);
                    var option     = self.radioButton( name, checked, htmlOptions );
                    var beginLabel = self.openTag( 'label', labelOptions );
                    var label      = self.label( labelTitle, htmlOptions['id'], labelOptions );
                    var endLabel   = self.closeTag('label');
                    
                    items.push( template.replaceArray(
                        ['{input}', '{beginLabel}', '{label}', '{labelTitle}', '{endLabel}'],
                        [option, beginLabel, label, labelTitle, endLabel]
                    ));
                });
                
                return items.join(separator);
            },
            
            listOptions: function(selection, listData, $htmlOptions ) {
                var self = this;
                var content = '';
                var htmlOptions = _.clone( $htmlOptions );
                
                if( htmlOptions['prompt'] ) {
                    content += $( '<option></option>' ).val('').html( htmlOptions['prompt'] ).outerHTML() + "\n";
                    delete htmlOptions['prompt'];
                }
                
                if( _.has(htmlOptions, 'empty') ) {
                    if( _.isString( htmlOptions['empty'] ) ) {
                        htmlOptions['empty'] = {'': htmlOptions['empty']};
                    }
                    
                    _.each(htmlOptions['empty'], function(label, value){
                        content += $( '<option></option>' ).val( value ).html( label ).outerHTML() + "\n";
                    });
                    
                    delete htmlOptions['empty'];
                }
                
                var options = [];
                if( htmlOptions['options'] ) {
                    options = htmlOptions['options'];
                    delete htmlOptions['options'];
                }
                
                var key = (htmlOptions['key'] || 'primaryKey');
                
                if( _.isArray(selection) ) {
                    _.each(selection, function(item, i){
                        if(_.isObject(item)) {
                            selection[i] = item[key];
                        }
                    });
                }
                else if( _.isObject(selection) ) {
                    selection = selection[key];
                }
                
                _.each(listData, function(value, key){
                    if( _.isObject( value ) ) {
                        content += self.tag(
                            'optgroup', 
                            {'label': key},
                            self.listOptions(selection, value, {'options': options})
                        ) + "\n";
                    }
                    else {
                        var attributes = {'value': key};
                        if( ( !_.isArray( selection ) && ( key == selection ) ) || ( _.isArray( selection ) && self.inArray(selection, key) ))
                            attributes['selected']='selected';
                        
                        if( options[ key ] )
                            attributes = $.extend( true, {}, attributes, options[ key ] );
                        
                        content += self.tag('option', attributes,  value) + "\n";
                    }
                });
                
                delete htmlOptions['key'];
                
                return content;
            },
            
            inputField: function( type, name, value, $htmlOptions ){
                var htmlOptions = $.extend( true, {}, ( $htmlOptions || {} ) , { 'type': type, 'value': value, 'name': name });
                
                if( !_.has(htmlOptions, 'id') ) {
                    htmlOptions['id'] = this.toIdByName( name );
                }
                
                return this.tag('input', htmlOptions);
            },
            
            label: function(label, $for, $htmlOptions) {
                var htmlOptions = _.clone( $htmlOptions );
                
                if($for===false)
                    delete htmlOptions['for'];
                else
                    htmlOptions['for'] = $for;
                
                return this.tag( 'label', htmlOptions, label );
            },
            
            tag: function(name, htmlOptions, content){
                return $('<' + name + '/>', (htmlOptions || {}) ).html(content).outerHTML();
            },
            
            openTag: function(name, htmlOptions){
                var html = this.tag(name, htmlOptions);
                return html.substr(0, (html.length - (name.length + 3)));
            },
            
            closeTag: function(name){
                return '</' + name + '>';
            },
            
            toIdByName: function(name) {
                return name.replace('[]', '').replace('][', '_').replace('[', '_').replace('[', '_');
            },
            
            inArray: function(data, val){
                var exists = false;
                
                _.each( data, function( value ){
                    if( value == val ) {
                         exists = true;
                    }
                });
                
                return exists;
            }
        }
    };
    
    $.fn.outerHTML = function() {
       return (this[0]) ? this[0].outerHTML : ''; 
    };
    
    String.prototype.replaceArray = function(find, replace) {
        var replaceString = this;
        var regex; 
        for (var i = 0; i < find.length; i++) {
            regex = new RegExp(find[i], "g");
            replaceString = replaceString.replace(regex, replace[i]);
        }
        return replaceString;
    };
    
    Backbone.fn.View.extend = function(protoProps, staticProps) {
        var parent = this;
        var child;
        
        // The constructor function for the new subclass is either defined by you
        // (the "constructor" property in your `extend` definition), or defaulted
        // by us to simply call the parent constructor.
        if (protoProps && _.has(protoProps, 'constructor')) {
           child = protoProps.constructor;
        } else {
           child = function(){ return parent.apply(this, arguments); };
        }
        
        // Add static properties to the constructor function, if supplied.
        _.extend(child, parent, staticProps);
        
        // Set the prototype chain to inherit from `parent`, without calling
        // `parent`'s constructor function and add the prototype properties.
        
        if( protoProps.events ) {
            _.each( parent.prototype.events, function(fnName, name){
                protoProps.events[name] = fnName;
            });
        }
        
        child.prototype = _.create(parent.prototype, protoProps);
        child.prototype.constructor = child;
        
        // Set a convenience property in case the parent's prototype is needed
        // later.
        child.__super__ = parent.prototype;
        
        var render = child.prototype.render;
        
        child.prototype.render = function(){
            parent.prototype._before_render.call(this);
            var result = render.call(this);
            parent.prototype._after_render.call(this);
            return result;
        };
        
        return child;
    };
    _.fn({'$el': Backbone.fn.Element});
    _.mixin(Backbone.fn.Element);
}(window.jQuery));