package com.medinet.hl7.utils;

import com.google.gson.Gson;

public class JsonUtils {
	public static String toJson(Object data){
		Gson gson = new Gson();
		return gson.toJson(data);
	}
}
