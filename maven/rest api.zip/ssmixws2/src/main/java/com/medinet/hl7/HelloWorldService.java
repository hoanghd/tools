package com.medinet.hl7;
 
import javax.ws.rs.*;
import javax.ws.rs.core.*;

import java.util.Map;
import java.util.HashMap;
import com.medinet.hl7.utils.JsonUtils;

@Path("/hello")
public class HelloWorldService {
	@GET
	@Path("/get/{param}")
	public Response getMsg(@PathParam("param") String msg) { 
		Map<String, String> data = new HashMap<String, String>();
		data.put("msg", msg);
		
		return Response.status(200)
				.header("Content-Type", MediaType.APPLICATION_JSON)
				.entity(JsonUtils.toJson(data))
				.build(); 
	}
	
	@POST
	@Path("/post")
	@Consumes("application/x-www-form-urlencoded")
	public Response postMsg(MultivaluedMap<String, String> form){		
		Map<String, Object> data = new HashMap<String, Object>();
		data.put("form", form);		
		
		return Response.status(200)
				.header("Content-Type", MediaType.APPLICATION_JSON)
				.entity(JsonUtils.toJson(data))
				.build(); 
	}
}