package com.medinet.hl7;
 
import java.util.HashMap;
import java.util.Map;

import javax.ws.rs.*;
import javax.ws.rs.core.*;

import com.medinet.hl7.utils.JsonUtils;

@Path("/hello")
public class HelloWorldService {
	@GET
	@Path("/get/{param}")
	public Response getMsg(@PathParam("param") String msg) { 
		Map<String, String> data = new HashMap<String, String>();
		data.put("msg", msg);
		
		return Response.status(200)
				.header("Content-Type", MediaType.APPLICATION_JSON)
				.entity(JsonUtils.toJson(data))
				.build(); 
	}
	
	@POST
	@Path("/post")
	public Response postMsg(@FormParam("pid") String pid,
							@FormParam("name") String name){
		
		Map<String, Object> data = new HashMap<String, Object>();
		data.put("pid", pid);
		data.put("name", name);
		
		return Response.status(200)
				.header("Content-Type", MediaType.APPLICATION_JSON)
				.entity(JsonUtils.toJson(data))
				.build(); 
	}
}