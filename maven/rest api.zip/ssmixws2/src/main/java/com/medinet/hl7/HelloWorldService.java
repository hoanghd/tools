package com.medinet.hl7;
 
import java.util.HashMap;
import java.util.Map;

import javax.ws.rs.*;
import javax.ws.rs.core.*;
import com.medinet.hl7.utils.JsonUtils;

@Path("/hello")
public class HelloWorldService {
	@GET
	@Path("/{param}")
	@Consumes(MediaType.APPLICATION_JSON)
	public Response getMsg(@PathParam("param") String msg) { 
		Map<String, String> data = new HashMap<String, String>();
		data.put("msg", msg);
		
		return Response.status(200)
				.entity(JsonUtils.toJson(data))
				.build(); 
	}
}